"use strict";
// Browser discovery + launch. Uses the user's installed Chrome/Edge/Chromium
// (or CAPTURE_BROWSER / config.browserPath). We never download a browser.

const fs = require("node:fs");
const path = require("node:path");
const { spawn, execFileSync } = require("node:child_process");

function windowsCandidates() {
  const roots = [
    process.env.PROGRAMFILES,
    process.env["PROGRAMFILES(X86)"],
    process.env.LOCALAPPDATA,
  ].filter(Boolean);
  const rels = [
    "Google/Chrome/Application/chrome.exe",
    "Microsoft/Edge/Application/msedge.exe",
    "Chromium/Application/chrome.exe",
    "BraveSoftware/Brave-Browser/Application/brave.exe",
  ];
  const out = [];
  for (const root of roots) for (const rel of rels) out.push(path.join(root, ...rel.split("/")));
  return out;
}

function unixCandidates() {
  const names = ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "brave-browser"];
  const out = [];
  for (const name of names) {
    try {
      const p = execFileSync("which", [name], { encoding: "utf8" }).trim();
      if (p) out.push(p);
    } catch {
      /* not present */
    }
  }
  return out;
}

function findBrowser(explicit) {
  const candidates = [];
  if (explicit) candidates.push(explicit);
  if (process.env.CAPTURE_BROWSER) candidates.push(process.env.CAPTURE_BROWSER);
  candidates.push(...(process.platform === "win32" ? windowsCandidates() : unixCandidates()));
  for (const c of candidates) {
    if (c && fs.existsSync(c)) return c;
  }
  return null;
}

function waitForDevToolsPort(profileDir, timeoutMs = 20000) {
  const portFile = path.join(profileDir, "DevToolsActivePort");
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const tick = () => {
      try {
        const content = fs.readFileSync(portFile, "utf8");
        const port = parseInt(content.split(/\r?\n/)[0], 10);
        if (Number.isInteger(port) && port > 0) return resolve(port);
      } catch {
        /* not written yet */
      }
      if (Date.now() - started > timeoutMs) {
        reject(new Error("Browser did not expose a DevTools port in time. Is another instance using this profile?"));
      } else {
        setTimeout(tick, 200);
      }
    };
    tick();
  });
}

function launchBrowser({ browserPath, profileDir, url, headless }) {
  fs.mkdirSync(profileDir, { recursive: true });
  const args = [
    "--remote-debugging-port=0",
    `--user-data-dir=${profileDir}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-popup-blocking",
  ];
  if (headless) args.push("--headless=new", "--disable-gpu", "--window-size=1280,900");
  args.push(url || "about:blank");
  const child = spawn(browserPath, args, { stdio: "ignore", detached: false });
  return child;
}

module.exports = { findBrowser, launchBrowser, waitForDevToolsPort };
