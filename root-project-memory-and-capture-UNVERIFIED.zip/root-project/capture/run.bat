@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or not in PATH.
  echo Run install.bat first - it explains exactly what to install.
  pause
  exit /b 1
)
echo Starting capture tool... A normal browser window will open.
echo Log in and use the site manually. Press Q here to stop and save.
node tool\main.cjs %*
echo.
echo Capture finished. Session folder is under capture-sessions\
pause
