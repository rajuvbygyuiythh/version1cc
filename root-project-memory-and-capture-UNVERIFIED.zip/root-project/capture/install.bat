@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  Capture tool - one-time setup check
echo  No npm packages are needed: the tool uses Node built-ins
echo  plus your installed Chrome or Edge browser.
echo ============================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [MISSING] Node.js was not found.
  echo Install Node.js 22 LTS from https://nodejs.org  ^(or run: winget install OpenJS.NodeJS.LTS^)
  echo Then close this window and run install.bat again.
  pause
  exit /b 1
)
for /f "tokens=1 delims=v" %%a in ('node -v') do set NODEVER=%%a
echo [OK] Node.js found: 
node -v
echo.
set BROWSERFOUND=
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set BROWSERFOUND=Google Chrome
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set BROWSERFOUND=Google Chrome
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set BROWSERFOUND=Microsoft Edge
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set BROWSERFOUND=Microsoft Edge
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set BROWSERFOUND=Google Chrome
if defined BROWSERFOUND (
  echo [OK] Browser found: %BROWSERFOUND%
) else (
  echo [MISSING] Chrome/Edge was not found in the usual locations.
  echo Install Google Chrome, or set "browserPath" in capture.config.json.
)
echo.
if not exist capture-sessions mkdir capture-sessions
if not exist profiles mkdir profiles
echo [OK] Folders ready: capture-sessions\ and profiles\
echo.
echo Setup check complete. Now double-click run.bat to start capturing.
pause
