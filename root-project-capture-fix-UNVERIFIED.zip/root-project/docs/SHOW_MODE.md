# Show Mode (third Browser row)

Available options: 01 Rod, 02 ChromeDP, 03 Show Mode. Each has Run.

Show Mode is a visible Rod preset, NOT Camoufox or an anti-detection feature.
Run sends show_mode; both frontend and backend force Headless=false. Backend
validation converts it to rod BEFORE saving defaults and dispatching captures.
The persisted login backend remains rod, so existing session consumers work.

Profile, Count (1–5), proxy assignment, authentication check, login JSON saving
and close/cleanup reuse the existing flow. Login is completed in the browser;
this does not add automatic credential entry. The browser closes once login is
saved, as in the other two rows.

The current checkbox is not changed by the click. Rod/ChromeDP continue to use
it normally. On restart, last accepted defaults from Show Mode are Rod/headless
false. No separate backend driver, binding type or storage schema was added.

Checks: frontend tests cover row/count/button routing and Headless override;
Go tests cover normalization, dispatch and saved defaults. The isolated Go
normalization test can run independently of Windows dependencies; full app tests
remain subject to the delivered verification report. No live browser was run.
