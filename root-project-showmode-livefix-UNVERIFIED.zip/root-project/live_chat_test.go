package main

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync"
	"testing"
	"time"

	"chitchatbot/internal/browser"
	"chitchatbot/internal/model"
)

// fakeLiveBackend implements browser.Backend + browser.ChatMessageSource with
// the capture-proven ChitChat API shapes. No browser is launched.
type fakeLiveBackend struct {
	mu          sync.Mutex
	handler     func(browser.ChatMessage)
	activeID    string
	sentBodies  []string
	disconnects int
	matches     int
	history     []browser.ChatMessage
}

func (f *fakeLiveBackend) Name() string { return "rod" }
func (f *fakeLiveBackend) Start(context.Context, browser.Options) error {
	return nil
}
func (f *fakeLiveBackend) CaptureSession(context.Context) (model.LoginInfo, error) {
	return model.LoginInfo{}, nil
}
func (f *fakeLiveBackend) Close() error { return nil }
func (f *fakeLiveBackend) SubscribeChatMessages(_ context.Context, h func(browser.ChatMessage)) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.handler = h
	return nil
}

func (f *fakeLiveBackend) Fetch(_ context.Context, req browser.FetchRequest) (browser.FetchResponse, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	ok := func(status int, text string) (browser.FetchResponse, error) {
		return browser.FetchResponse{OK: status >= 200 && status < 300, Status: status, Text: text}, nil
	}
	switch {
	case strings.Contains(req.URL, "/match/active"):
		if f.activeID == "" {
			return ok(200, `{"match":null}`)
		}
		return ok(200, fmt.Sprintf(`{"match":{"conversation":{"id":%q}}}`, f.activeID))
	case strings.HasSuffix(req.URL, "/match/disconnect"):
		f.disconnects++
		f.activeID = ""
		return ok(200, `{}`)
	case strings.HasSuffix(req.URL, "/match"):
		f.matches++
		f.activeID = "conv-next"
		return ok(201, `{"matched":true}`)
	case strings.Contains(req.URL, "/messages") && req.Method == "GET":
		data, _ := json.Marshal(f.history)
		return ok(200, string(data))
	case strings.Contains(req.URL, "/messages") && req.Method == "POST":
		body := ""
		if req.Body != nil {
			body = *req.Body
		}
		f.sentBodies = append(f.sentBodies, body)
		return ok(201, `{}`)
	default:
		return ok(200, `{}`)
	}
}

func (f *fakeLiveBackend) push(m browser.ChatMessage) {
	f.mu.Lock()
	h := f.handler
	f.mu.Unlock()
	if h != nil {
		h(m)
	}
}

func (f *fakeLiveBackend) sentContaining(text string) int {
	f.mu.Lock()
	defer f.mu.Unlock()
	n := 0
	for _, b := range f.sentBodies {
		if strings.Contains(b, text) {
			n++
		}
	}
	return n
}

func (f *fakeLiveBackend) setHistory(msgs []browser.ChatMessage) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.history = msgs
}

func (f *fakeLiveBackend) stats() (disconnects, matches int) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.disconnects, f.matches
}

func waitForLive(t *testing.T, what string, cond func() bool) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if cond() {
			return
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Fatalf("timed out waiting for %s", what)
}

func testLiveRunner(a *App, fake *fakeLiveBackend) *liveRunner {
	return &liveRunner{
		api:          &liveChatAPI{backend: fake},
		ownID:        "me",
		prefix:       "[test show-live]",
		logf:         func(string, string) {},
		replyDelay:   time.Millisecond,
		pollInterval: 25 * time.Millisecond,
		seen:         make(map[string]bool),
		newResponder: a.newLiveResponder,
	}
}

func TestLiveChatStartsRepliesAndSkips(t *testing.T) {
	a := browserTestApp(t)
	if err := a.SaveMessageSettings(model.NewMessageSettings("hello first\nreply line", "")); err != nil {
		t.Fatal(err)
	}
	fake := &fakeLiveBackend{activeID: "conv1"}
	r := testLiveRunner(a, fake)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go r.run(ctx, fake)

	// Conversation start sends the first sequence line proactively.
	waitForLive(t, "start line", func() bool { return fake.sentContaining("hello first") == 1 })

	// Own messages are ignored (no echo replies to ourselves).
	fake.push(browser.ChatMessage{ID: "own1", ConversationID: "conv1", AuthorID: "me", Content: "hello first"})
	time.Sleep(150 * time.Millisecond)
	if n := fake.sentContaining("reply line"); n != 0 {
		t.Fatalf("own message triggered a reply (%d)", n)
	}

	// Partner message gets the next sequence line.
	fake.push(browser.ChatMessage{ID: "m1", ConversationID: "conv1", AuthorID: "partner", Content: "hi"})
	waitForLive(t, "reply line", func() bool { return fake.sentContaining("reply line") == 1 })

	// Duplicate delivery of the same message does not reply twice.
	fake.push(browser.ChatMessage{ID: "m1", ConversationID: "conv1", AuthorID: "partner", Content: "hi"})
	time.Sleep(150 * time.Millisecond)
	if n := fake.sentContaining("reply line"); n != 1 {
		t.Fatalf("duplicate message replied %d times", n)
	}

	// Sequence exhausted -> skip: disconnect + new match + greeting again.
	fake.push(browser.ChatMessage{ID: "m2", ConversationID: "conv1", AuthorID: "partner", Content: "more"})
	waitForLive(t, "skip disconnect", func() bool {
		d, _ := fake.stats()
		return d >= 1
	})
	waitForLive(t, "new conversation greeting", func() bool { return fake.sentContaining("hello first") >= 2 })
}

func TestLiveChatEVAResponderStarts(t *testing.T) {
	a := browserTestApp(t)
	settings := model.NewMessageSettings("", "")
	settings.ChatMode = model.ChatModeEVAChat
	if err := a.SaveMessageSettings(settings); err != nil {
		t.Fatal(err)
	}
	responder, mode, err := a.newLiveResponder()
	if err != nil {
		t.Fatalf("EVA responder: %v", err)
	}
	if mode != "EVAChat Flow" {
		t.Fatalf("unexpected mode %q", mode)
	}
	if lines := responder.Start(); len(lines) == 0 {
		t.Fatal("EVA Start should produce a greeting line from the starter pack")
	}
}

func TestLiveChatPollingFallbackDetectsIncoming(t *testing.T) {
	a := browserTestApp(t)
	if err := a.SaveMessageSettings(model.NewMessageSettings("hello first\nreply line", "")); err != nil {
		t.Fatal(err)
	}
	fake := &fakeLiveBackend{activeID: "conv1"}
	r := testLiveRunner(a, fake)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go r.run(ctx, fake)

	waitForLive(t, "start line", func() bool { return fake.sentContaining("hello first") == 1 })
	// No socket push at all: the message only appears in history polling.
	fake.setHistory([]browser.ChatMessage{
		{ID: "p1", ConversationID: "conv1", AuthorID: "partner", Content: "hi from poll", CreatedAt: "2026-10-14T00:00:01Z"},
	})
	waitForLive(t, "poll-detected reply", func() bool { return fake.sentContaining("reply line") == 1 })
}

func TestLiveFolderResponderPicksOneSequencePerConversation(t *testing.T) {
	a := browserTestApp(t)
	settings := model.NewMessageSettings("", "")
	settings.ChatMode = model.ChatModeFolder
	settings.LoadedSequences = []string{"greet one\nreply one", "greet two\nreply two"}
	settings.UseLoadedSequences = true
	if err := a.SaveMessageSettings(settings); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 12; i++ {
		responder, mode, err := a.newLiveResponder()
		if err != nil {
			t.Fatal(err)
		}
		if mode != model.ChatModeFolder {
			t.Fatalf("mode = %q", mode)
		}
		start := responder.Start()
		reply, end := responder.Reply("hi")
		if len(start) != 1 || len(reply) != 1 || end {
			t.Fatalf("bad flow: start=%v reply=%v end=%v", start, reply, end)
		}
		// Greeting and reply must come from the SAME sequence file.
		if (start[0] == "greet one") != (reply[0] == "reply one") {
			t.Fatalf("mixed sequences: %q then %q", start[0], reply[0])
		}
	}
}
