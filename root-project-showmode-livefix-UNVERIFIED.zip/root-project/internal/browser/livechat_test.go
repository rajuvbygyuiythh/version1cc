package browser

import "testing"

func TestParseChatMessageFrame(t *testing.T) {
	// Real shape (matches internal/bot realtime.go): author is an OBJECT.
	payload := `42["chatMessage",{"message":{"id":"m1","conversationId":"c1","author":{"id":"u2","username":"partner name"},"content":"hello there","type":"TEXT","createdAt":"2026-10-14T12:54:05Z"}}]`
	msg, ok := ParseChatMessageFrame(payload)
	if !ok {
		t.Fatal("expected chatMessage frame to parse")
	}
	if msg.ID != "m1" || msg.ConversationID != "c1" || msg.AuthorID != "u2" || msg.AuthorName != "partner name" || msg.Content != "hello there" || msg.Type != "TEXT" {
		t.Fatalf("unexpected message: %#v", msg)
	}
}

func TestParseChatMessageFrameRejectsOtherPackets(t *testing.T) {
	for _, payload := range []string{
		"",
		"2",
		"3",
		`40{"release":"abc"}`,
		`42["typing",{"userId":"u2","conversationId":"c1"}]`,
		`42["presenceSync"]`,
		`42["chatMessage",{"message":{"id":"","conversationId":"c1","content":"x"}}]`,
		`42["chatMessage",{"message":{"id":"m1","conversationId":"c1","content":"  "}}]`,
		"not json",
	} {
		if msg, ok := ParseChatMessageFrame(payload); ok {
			t.Fatalf("accepted non-chat payload %q: %#v", payload, msg)
		}
	}
}

func TestParseChatMessageFrameAuthorShapes(t *testing.T) {
	// Plain-string author (seen in some HTTP responses).
	msg, ok := ParseChatMessageFrame(`{"message":{"id":"m","conversationId":"c","author":"some name","content":"hi"}}`)
	if !ok || msg.AuthorName != "some name" {
		t.Fatalf("string author: ok=%v msg=%#v", ok, msg)
	}
	// Null author must not break parsing.
	msg, ok = ParseChatMessageFrame(`{"message":{"id":"m","conversationId":"c","author":null,"content":"hi"}}`)
	if !ok || msg.AuthorID != "" {
		t.Fatalf("null author: ok=%v msg=%#v", ok, msg)
	}
}

func TestParseChatMessageFrameBareShapes(t *testing.T) {
	if _, ok := ParseChatMessageFrame(`{"message":{"id":"m","conversationId":"c","author":"a","content":"hi"}}`); !ok {
		t.Fatal("bare object should parse")
	}
	if _, ok := ParseChatMessageFrame(`["chatMessage",{"message":{"id":"m","conversationId":"c","author":"a","content":"hi"}}]`); !ok {
		t.Fatal("bare array should parse")
	}
}
