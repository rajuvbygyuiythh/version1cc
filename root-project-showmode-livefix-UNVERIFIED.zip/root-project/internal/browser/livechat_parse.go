package browser

import (
	"encoding/json"
	"strings"
)

// ChatMessage is one realtime chat message observed on the page's Socket.IO
// connection or via the messages history API. The schema mirrors
// docs/CHITCHAT_PROTOCOL.md (capture-proven) and the parsing used by the
// existing internal/bot realtime client.
//
// IMPORTANT: the real payload's `author` is an OBJECT ({id, username}),
// sometimes a plain username string (some HTTP responses), sometimes null.
// An earlier version of this parser declared Author as a string, which made
// every real chatMessage frame fail to parse — no incoming was ever seen.
type ChatMessage struct {
	ID             string `json:"id"`
	ConversationID string `json:"conversationId"`
	AuthorID       string `json:"-"`
	AuthorName     string `json:"-"`
	Content        string `json:"content"`
	Type           string `json:"type"`
	CreatedAt      string `json:"createdAt"`
}

// UnmarshalJSON decodes the message plus every observed `author` shape:
// "userId" | {"id": "...", "username": "..."} | null.
func (m *ChatMessage) UnmarshalJSON(data []byte) error {
	var raw struct {
		ID             string          `json:"id"`
		ConversationID string          `json:"conversationId"`
		Author         json.RawMessage `json:"author"`
		Content        string          `json:"content"`
		Type           string          `json:"type"`
		CreatedAt      string          `json:"createdAt"`
	}
	if err := json.Unmarshal(data, &raw); err != nil {
		return err
	}
	m.ID = raw.ID
	m.ConversationID = raw.ConversationID
	m.Content = raw.Content
	m.Type = raw.Type
	m.CreatedAt = raw.CreatedAt
	m.AuthorID = ""
	m.AuthorName = ""

	author := strings.TrimSpace(string(raw.Author))
	if author == "" || author == "null" {
		return nil
	}
	if strings.HasPrefix(author, "\"") {
		// Some API responses carry the username (or id) as a plain string.
		_ = json.Unmarshal(raw.Author, &m.AuthorName)
		return nil
	}
	var obj struct {
		ID       string `json:"id"`
		Username string `json:"username"`
	}
	if err := json.Unmarshal(raw.Author, &obj); err == nil {
		m.AuthorID = obj.ID
		m.AuthorName = obj.Username
	}
	return nil
}

// MarshalJSON keeps test fixtures and logs simple (author as object).
func (m ChatMessage) MarshalJSON() ([]byte, error) {
	type alias ChatMessage
	out := struct {
		alias
		Author any `json:"author"`
	}{alias: alias(m)}
	if m.AuthorID != "" || m.AuthorName != "" {
		out.Author = map[string]string{"id": m.AuthorID, "username": m.AuthorName}
	}
	return json.Marshal(out)
}

// ParseChatMessageFrame extracts a chatMessage event from a raw Socket.IO
// WebSocket frame payload. Accepted shapes:
//   - engine.io event packet: 42["chatMessage", {"message": {...}}]
//   - a bare JSON array:      ["chatMessage", {"message": {...}}]
//   - a bare JSON object:     {"message": {...}}
//
// Anything else (pings, presence, typing, connect packets) returns false.
func ParseChatMessageFrame(payload string) (ChatMessage, bool) {
	data := strings.TrimSpace(payload)
	if data == "" {
		return ChatMessage{}, false
	}

	// Strip the engine.io/Socket.IO packet-type digits (e.g. "42").
	if data[0] >= '0' && data[0] <= '9' {
		i := 0
		for i < len(data) && data[i] >= '0' && data[i] <= '9' {
			i++
		}
		data = strings.TrimSpace(data[i:])
		if data == "" {
			return ChatMessage{}, false
		}
	}

	if strings.HasPrefix(data, "[") {
		var arr []json.RawMessage
		if err := json.Unmarshal([]byte(data), &arr); err != nil || len(arr) < 2 {
			return ChatMessage{}, false
		}
		var event string
		if err := json.Unmarshal(arr[0], &event); err != nil || event != "chatMessage" {
			return ChatMessage{}, false
		}
		data = string(arr[1])
	}

	var envelope struct {
		Message ChatMessage `json:"message"`
	}
	if err := json.Unmarshal([]byte(data), &envelope); err != nil {
		return ChatMessage{}, false
	}
	msg := envelope.Message
	if msg.ID == "" || msg.ConversationID == "" || strings.TrimSpace(msg.Content) == "" {
		return ChatMessage{}, false
	}
	return msg, true
}
