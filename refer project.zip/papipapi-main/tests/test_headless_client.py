#!/usr/bin/env python3
"""Offline checks for the browserless (Socket.IO) path.

A. Frame parsing  — the Socket.IO CONNECT frame -> ``release`` token
B. Session file   — save/load, cookie scoping, file permissions
C. Client wiring  — auth payload + headers, and NO Authorization header
D. End-to-end     — a REAL local Socket.IO server plus a REAL HTTP API on
                    127.0.0.1: the worker connects with the release token,
                    receives ``chatMessage`` over the socket, ignores its own
                    echo, POSTs the reply, and queues the next match when the
                    conversation closes.  No browser, no internet.

Run:  python tests/test_headless_client.py
Needs: pip install 'python-socketio[client]' aiohttp websockets
"""
from __future__ import annotations

import asyncio
import os
import stat
from urllib.parse import unquote_plus
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from headless.capture import (          # noqa: E402  (pure helpers, no browser)
    extract_release,
    origin_of,
    parse_connect_frame,
    parse_ws_url,
    summarize_frames,
)
from headless.session_file import (     # noqa: E402
    HeadlessSession,
    cookie_header,
    cookie_matches,
    cookies_for_aiohttp,
    load_session,
    save_session,
    session_path,
    SessionError,
)

PASS = 0
FAIL = 0
FAILURES: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  [OK ] {name}")
    else:
        FAIL += 1
        FAILURES.append(name)
        print(f"  [FAIL] {name} {detail}")


# ---------------------------------------------------------------------------
# A. Engine.IO / Socket.IO frame parsing
# ---------------------------------------------------------------------------

def test_frames() -> None:
    print("\n— A. Socket.IO frame parsing —")
    frame = '40{"release":"9f2c1ab7d4e5"}'
    check("CONNECT frame is recognised", parse_connect_frame(frame) == {"release": "9f2c1ab7d4e5"},
          str(parse_connect_frame(frame)))
    check("release token is extracted", extract_release(frame) == "9f2c1ab7d4e5")
    check("namespaced CONNECT is handled",
          extract_release('40/chat,{"release":"abc"}') == "abc")
    check("an Engine.IO open frame is not a CONNECT",
          parse_connect_frame('0{"sid":"x","pingInterval":25000,"upgrades":[]}') is None)
    check("a ping frame is ignored", parse_connect_frame("2") is None)
    check("an event frame is not a CONNECT",
          parse_connect_frame('42["chatMessage",{"message":{}}]') is None)
    check("garbage does not raise", parse_connect_frame("40{not json") is None)
    check("bytes frames are decoded",
          extract_release(b'40{"release":"ff00"}') == "ff00")
    check("empty release -> empty string", extract_release("40{}") == "")

    base, path = parse_ws_url("wss://api.chitchat.gg/socket.io/?EIO=4&transport=websocket")
    check("ws url -> https api base", base == "https://api.chitchat.gg", base)
    check("ws url -> socket.io path", path == "/socket.io", path)
    check("origin_of keeps scheme+host", origin_of("https://app.chitchat.gg/start/new")
          == "https://app.chitchat.gg")
    counts = summarize_frames(['0{"sid":"x"}', "2", "3", '40{"release":"a"}',
                               '42["chatMessage",{}]', '42["typing",{}]'])
    check("frame summary counts each type",
          counts.get("socketio.connect") == 1 and counts.get("socketio.event") == 2
          and counts.get("engineio.ping") == 1, str(counts))


# ---------------------------------------------------------------------------
# B. Session file
# ---------------------------------------------------------------------------

def _sample_session(**over) -> HeadlessSession:
    data = dict(
        account="eva@example.com",
        release="9f2c1ab7d4e5",
        cookies=[
            {"name": "token", "value": "tok123", "domain": ".chitchat.gg", "path": "/"},
            {"name": "__Secure-text-session", "value": "sess999",
             "domain": "api.chitchat.gg", "path": "/"},
            {"name": "other-site", "value": "nope", "domain": "example.org", "path": "/"},
        ],
        api_base="https://api.chitchat.gg",
        socket_path="/socket.io",
        user={"id": "me-1", "username": "eva_test"},
        origin="https://app.chitchat.gg",
        user_agent="TestAgent/1.0",
    )
    data.update(over)
    return HeadlessSession(**data)


def test_session_file() -> None:
    print("\n— B. session persistence + cookie scoping —")
    with tempfile.TemporaryDirectory() as tmp:
        session = _sample_session()
        path = save_session(session, base_dir=tmp)
        check("session saved to the project-style path",
              path == session_path("eva@example.com", base_dir=tmp), str(path))
        mode = stat.S_IMODE(path.stat().st_mode)
        check("session file is 0600 (it holds live credentials)",
              mode == 0o600, oct(mode))
        loaded = load_session(account="eva@example.com", base_dir=tmp)
        check("round-trips account + release",
              loaded.account == session.account and loaded.release == session.release)
        check("round-trips all cookies", len(loaded.cookies) == 3)
        check("ws endpoint matches the captured one",
              loaded.ws_endpoint == "wss://api.chitchat.gg/socket.io/?EIO=4&transport=websocket",
              loaded.ws_endpoint)
        check("identity is exposed", loaded.user_id == "me-1" and loaded.username == "eva_test")
        check("no missing auth cookies for a good capture",
              loaded.missing_auth_cookies() == [])
        check("a capture without the login cookie is flagged",
              _sample_session(cookies=[{"name": "x", "value": "1",
                                        "domain": ".chitchat.gg"}]).missing_auth_cookies()
              == ["token", "__Secure-text-session"])

        try:
            save_session(_sample_session(release=""), base_dir=tmp)
            check("saving without a release token is refused", False)
        except SessionError:
            check("saving without a release token is refused", True)
        try:
            load_session(account="nobody@example.com", base_dir=tmp)
            check("loading a missing session raises SessionError", False)
        except SessionError:
            check("loading a missing session raises SessionError", True)

    header = cookie_header(_sample_session().cookies, "https://api.chitchat.gg/users/me")
    check("cookie header keeps both login cookies",
          "token=tok123" in header and "__Secure-text-session=sess999" in header, header)
    check("cookie header drops other sites' cookies", "other-site" not in header, header)
    check("parent-domain cookie covers the api subdomain",
          cookie_matches(".chitchat.gg", "api.chitchat.gg"))
    check("unrelated domain is rejected", not cookie_matches("example.org", "api.chitchat.gg"))
    check("aiohttp cookie dict matches the header",
          cookies_for_aiohttp(_sample_session().cookies, "https://api.chitchat.gg")
          == {"token": "tok123", "__Secure-text-session": "sess999"})


# ---------------------------------------------------------------------------
# C/D. need the async stack
# ---------------------------------------------------------------------------

def _async_stack():
    try:
        import aiohttp          # noqa: F401
        import socketio         # noqa: F401
        import websockets       # noqa: F401
        return None
    except ImportError as exc:
        return str(exc)


def test_client_wiring() -> None:
    print("\n— C. Socket.IO client wiring —")
    from headless.client import TRACKED_EVENTS, HeadlessChatClient

    session = _sample_session()
    client = HeadlessChatClient(session)
    check("auth payload is exactly {release: …} — the 40{…} CONNECT body",
          client.auth_payload == {"release": "9f2c1ab7d4e5"}, str(client.auth_payload))
    headers = client._connect_headers()
    check("the websocket request carries the login cookies",
          "token=tok123" in headers.get("cookie", ""), str(headers))
    check("no Authorization header is ever sent",
          not any(k.lower() == "authorization" for k in headers), str(list(headers)))
    check("Origin is set to the app origin", headers.get("origin") == "https://app.chitchat.gg")
    check("chatMessage is a tracked event", "chatMessage" in TRACKED_EVENTS)
    check("a client with no release token refuses to connect",
          not HeadlessChatClient(_sample_session(release="")).session.release)


async def _end_to_end() -> None:
    """Worker <-> real Socket.IO server <-> real HTTP API, all on localhost."""
    import aiohttp
    import socketio
    from aiohttp import web

    from headless.api import ChitchatAPI
    from headless.client import HeadlessChatClient
    from headless.worker import HeadlessWorker

    logs: list[str] = []
    seen = {"auth": None, "posts": [], "typing": [], "match": 0,
            "disconnect": 0, "auth_headers": [], "cookies": []}

    sio = socketio.AsyncServer(async_mode="aiohttp", cors_allowed_origins="*")
    app = web.Application()
    sio.attach(app)

    conversation_id = "6aca90fe2a3b576ad242c065"
    my_id = "6a7f6f60b8fb23b5edc818ad"
    peer_id = "6a927e118ac97f8d3cd10798"

    def _conversation(closed: bool = False) -> dict:
        return {
            "match": {
                "conversation": {"id": conversation_id, "participants": [],
                                 "category": "ENCOUNTER"},
                "users": [{"userId": my_id, "inactive": False},
                          {"userId": peer_id, "inactive": False}],
                "closure": {"closed": closed},
                "paused": False,
            },
            "inQueue": False,
        }

    def _message(author_id: str, content: str) -> dict:
        return {"message": {"id": f"m-{len(seen['posts'])}-{content}",
                            "conversationId": conversation_id,
                            "author": {"id": author_id, "username": "tester"},
                            "content": content, "type": "TEXT",
                            "status": "SENT", "flags": 0, "reactions": []}}

    @sio.event
    async def connect(sid, environ, auth):          # noqa: ANN001 - socketio signature
        seen["auth"] = auth
        sio.start_background_task(_script, sid)
        return True

    async def _script(sid: str) -> None:
        await sio.sleep(0.2)
        await sio.emit("matchUpdate", _conversation(), to=sid)
        await sio.sleep(0.2)
        await sio.emit("chatMessage", _message(peer_id, "hey"), to=sid)
        await sio.sleep(0.4)
        # our own message comes back over the socket too — must be ignored
        await sio.emit("chatMessage", _message(my_id, "hello u"), to=sid)
        await sio.sleep(0.4)
        await sio.emit("matchUpdate", _conversation(closed=True), to=sid)

    async def _handle_me(request):
        seen["auth_headers"].append(dict(request.headers))
        return web.json_response({"id": my_id, "username": "eva_test", "verified": True})

    async def _handle_active(request):
        return web.json_response({"inQueue": False})

    async def _handle_match(request):
        seen["match"] += 1
        return web.json_response({"ok": True}, status=201)

    async def _handle_disconnect(request):
        seen["disconnect"] += 1
        return web.json_response({}, status=200)

    async def _handle_typing(request):
        seen["typing"].append(request.match_info["cid"])
        return web.json_response({}, status=201)

    async def _handle_read(request):
        return web.json_response({}, status=200)

    async def _handle_post_message(request):
        body = await request.read()
        seen["posts"].append({
            "conversation": request.match_info["cid"],
            "content_type": request.content_type,
            "body": body.decode("utf-8", "replace"),
            "cookie": request.headers.get("cookie", ""),
            "headers": dict(request.headers),
        })
        return web.json_response(
            {"id": "srv-1", "conversationId": request.match_info["cid"],
             "content": "reply", "type": "TEXT", "status": "SENT"}, status=201)

    app.router.add_get("/users/me", _handle_me)
    app.router.add_get("/match/active", _handle_active)
    app.router.add_post("/match", _handle_match)
    app.router.add_patch("/match/disconnect", _handle_disconnect)
    app.router.add_post("/users/me/conversations/{cid}/typing", _handle_typing)
    app.router.add_patch("/users/me/conversations/{cid}/read", _handle_read)
    app.router.add_post("/users/me/conversations/{cid}/messages", _handle_post_message)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]      # noqa: SLF001 - test only
    base = f"http://127.0.0.1:{port}"

    session = _sample_session(api_base=base, socket_path="/socket.io", origin=base,
                              user={"id": my_id, "username": "eva_test"},
                              cookies=[{"name": "token", "value": "tok123",
                                        "domain": "127.0.0.1", "path": "/"},
                                       {"name": "__Secure-text-session", "value": "sess999",
                                        "domain": "127.0.0.1", "path": "/"}])

    client = HeadlessChatClient(session, log=logs.append, reconnection=False)
    api = ChitchatAPI(session, log=logs.append, message_mode="auto")
    worker = HeadlessWorker(client, api, log=logs.append, delay_scale=0.0)

    try:
        await client.connect(timeout=15)
        check("websocket CONNECT accepted by a real Socket.IO server", client.connected)
        check("the CONNECT frame carried the release token",
              seen["auth"] == {"release": "9f2c1ab7d4e5"}, str(seen["auth"]))
        check("Engine.IO heartbeat was negotiated", client.ping_interval > 0,
              f"{client.ping_interval}s")

        await worker.start()
        check("identity read from GET /users/me",
              worker.my_id == my_id and worker.username == "eva_test",
              f"{worker.my_id}/{worker.username}")

        await worker.ensure_match()
        check("a match was queued on start", seen["match"] >= 1, str(seen["match"]))

        async def _until_replied():
            # Drain the socket until the stranger was answered, our own echo
            # was ignored, and the closed conversation re-queued a match.
            for _ in range(40):
                if seen["posts"] and seen["disconnect"] and seen["match"] >= 2:
                    return
                item = await client.get_event(timeout=0.5)
                if item is not None:
                    await worker._dispatch(item)          # noqa: SLF001 - test drives it

        await asyncio.wait_for(_until_replied(), timeout=20)
    finally:
        worker.stop()
        await client.disconnect()
        await api.close()
        await runner.cleanup()

    check("the stranger's message produced exactly one reply POST",
          len(seen["posts"]) == 1, f"{len(seen['posts'])} posts: "
          f"{[p['body'][:60] for p in seen['posts']]}")
    if seen["posts"]:
        post = seen["posts"][0]
        check("the reply went to the right conversation",
              post["conversation"] == conversation_id, post["conversation"])
        check("the reply body carries real text from data/output/*.txt",
              len(post["body"]) > 5, post["body"][:120])
        decoded = unquote_plus(post["body"])
        check("the reply is what the engine produced",
              bool(worker.sent_texts) and worker.sent_texts[0] in decoded,
              f"sent={worker.sent_texts} body={decoded[:80]}")
        check("the POST was authenticated with cookies",
              "token=tok123" in post["cookie"], post["cookie"][:80])
        check("no Authorization header on the send request",
              not any(k.lower() == "authorization" for k in post["headers"]),
              str(list(post["headers"])))
    check("our own echoed chatMessage was NOT answered",
          len(seen["posts"]) == 1, f"posts={len(seen['posts'])}")
    check("a typing ping preceded the send", seen["typing"] == [conversation_id],
          str(seen["typing"]))
    check("closing the conversation queued the next match",
          seen["disconnect"] >= 1 and seen["match"] >= 2,
          f"disconnect={seen['disconnect']} match={seen['match']}")
    check("the worker counted the chat", worker.chats >= 1, str(worker.chats))
    check("stats report 1 message in / 1 out",
          worker.messages_in == 1 and worker.messages_out == 1,
          f"in={worker.messages_in} out={worker.messages_out}")


def test_end_to_end() -> None:
    print("\n— D. end-to-end: socket in, HTTP POST out (real local server) —")
    asyncio.run(_end_to_end())


def main() -> int:
    print("=" * 72)
    print("EVA headless (browserless Socket.IO) tests")
    print("=" * 72)
    test_frames()
    test_session_file()

    missing = _async_stack()
    if missing:
        print(f"\n  [SKIP] sections C+D — {missing}")
        print("         install with: pip install 'python-socketio[client]' aiohttp websockets")
    else:
        test_client_wiring()
        test_end_to_end()

    print("\n" + "=" * 72)
    print(f"RESULT: {PASS} passed, {FAIL} failed")
    for name in FAILURES:
        print(f"  - {name}")
    print("=" * 72)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
