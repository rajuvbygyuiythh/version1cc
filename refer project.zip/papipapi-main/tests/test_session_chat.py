#!/usr/bin/env python3
"""Checks for the dashboard's browser-less "Session Chat" feature.

A. Pure helpers   — log tagging, session rows, subprocess commands
B. Session list   — list/delete round-trip against a temp sessions dir
C. Controller     — SessionChatController against a REAL local Socket.IO server
                    plus a REAL HTTP API: connect with no browser, reply through
                    ChatRuleBot, POST the reply, stop cleanly from another thread
D. Dashboard GUI  — the real ChitchatBotGUI built offscreen: the Session Chat
                    page exists, lists saved sessions, and ▶ Start really chats
                    (socket in -> engine reply -> HTTP POST out) through the
                    QThread runner, then ■ Stop shuts it down.

Run:  python tests/test_session_chat.py
Needs: pip install 'python-socketio[client]' aiohttp websockets
       (section D also needs PyQt6; it skips when Qt cannot load)
"""
from __future__ import annotations

import asyncio
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from entry.session_chat import (          # noqa: E402
    build_capture_command,
    build_run_command,
    decorate_log,
    format_stats,
    relative_time,
    session_row,
    SessionChatController,
)
from headless.session_file import (       # noqa: E402
    HeadlessSession,
    delete_session,
    list_sessions,
    save_session,
)

PASS = 0
FAIL = 0
FAILURES: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  ✓ {name}")
    else:
        FAIL += 1
        FAILURES.append(name + (f"  [{detail}]" if detail else ""))
        print(f"  ✗ {name}" + (f"  [{detail}]" if detail else ""))


def _async_stack() -> str:
    for module in ("aiohttp", "socketio", "websockets"):
        try:
            __import__(module)
        except ImportError:
            return f"missing dependency: {module}"
    return ""


def _sample_session(account: str = "eva@test.com", **overrides) -> HeadlessSession:
    data = {
        "account": account,
        "release": "9f2c1ab7d4e5",
        "api_base": "http://127.0.0.1:1",
        "socket_path": "/socket.io",
        "origin": "https://app.chitchat.gg",
        "user_agent": "EVA-test",
        "created": "2026-10-11T01:29:23+00:00",
        "cookies": [{"name": "token", "value": "tok123", "domain": "127.0.0.1", "path": "/"}],
        "user": {"id": "", "username": ""},
    }
    data.update(overrides)
    return HeadlessSession(**data)


# ---------------------------------------------------------------------------
# A. PURE HELPERS
# ---------------------------------------------------------------------------
def test_helpers() -> None:
    print("\n— A. pure helpers (no Qt, no network) —")

    check("worker login line -> [WS] Connected tag",
          decorate_log("[headless] logged in as eva (id=6a7f6f60…)")
          .startswith("[WS] Connected — no browser needed ✓"),
          decorate_log("[headless] logged in as eva (id=6a7f6f60…)"))
    check("chat start -> [MATCH] New stranger found",
          decorate_log("[headless] chat #3 started (conversation=6aca90fe2a3b…)")
          == "[MATCH] New stranger found (chat #3)")
    check("chat end -> [MATCH] Conversation closed",
          "Conversation closed" in
          decorate_log("[headless] chat #3 ended (peer left) — 4 in / 5 out"))
    check("stranger message -> [RECV]",
          decorate_log("  wont zation> hey") == "[RECV] wont zation> hey")
    check("bot reply -> [SEND]", decorate_log("  eva> hello u") == "[SEND] hello u")
    check("[SEND] wins over [RECV] for the eva prefix",
          not decorate_log("  eva> hi").startswith("[RECV]"))
    check("a message containing '>' keeps its text",
          decorate_log("  bob> a > b") == "[RECV] bob> a > b")
    check("queue line -> [MATCH]",
          decorate_log("[headless] queued for the next stranger")
          == "[MATCH] Queued for the next stranger")
    check("unknown line passes through unchanged",
          decorate_log("[typing] 3 events") == "[typing] 3 events")

    check("relative_time: minutes", relative_time("2026-10-11T00:30:00",
          __import__("datetime").datetime(2026, 10, 11, 1, 0, 0)) == "30m ago")
    check("relative_time: hours", relative_time("2026-10-10T23:00:00",
          __import__("datetime").datetime(2026, 10, 11, 1, 0, 0)) == "2h ago")
    check("relative_time: days", relative_time("2026-10-09T01:00:00",
          __import__("datetime").datetime(2026, 10, 11, 1, 0, 0)) == "2d ago")
    check("relative_time: missing value", relative_time(None) == "unknown")
    check("relative_time: unparseable value is shown as-is",
          relative_time("yesterday") == "yesterday")

    check("format_stats counters", format_stats({"chats": 12, "messages_out": 47,
          "messages_in": 31}) == "Chats: 12 | Sent: 47 | Recv: 31")
    check("format_stats without stats", format_stats(None).startswith("Chats: 0"))

    # list_sessions() flattens the username — there is no nested "user" dict.
    row = session_row({"account": "me@mail.com", "username": "eva_x",
                       "created": None, "cookies": 2, "has_release": True})
    check("session_row reads the FLAT username", row["username"] == "eva_x", str(row))
    check("session_row: usable needs release AND cookies", row["usable"] is True)
    check("session_row: no release -> not usable",
          session_row({"account": "a", "cookies": 1, "has_release": False})["usable"] is False)
    check("session_row: missing username falls back",
          session_row({"account": "a"})["username"] == "unknown")

    cmd = build_capture_command("Me@Mail.com")
    check("capture command shape", cmd[1:] == ["run_headless.py", "--capture",
          "--account", "Me@Mail.com"], str(cmd))
    check("capture command uses the current interpreter by default",
          cmd[0] == sys.executable)
    check("capture command honours --headless / --wait",
          build_capture_command("a@b.c", headed=False, wait_seconds=60)
          == [sys.executable, "run_headless.py", "--capture", "--account", "a@b.c",
              "--headless", "--wait", "60"])
    try:
        build_capture_command("   ")
        check("capture command rejects an empty account", False)
    except ValueError:
        check("capture command rejects an empty account", True)
    check("run command shape", build_run_command("a@b.c")[1:]
          == ["run_headless.py", "--run", "--account", "a@b.c"])


# ---------------------------------------------------------------------------
# B. SESSION LIST ROUND-TRIP
# ---------------------------------------------------------------------------
def test_session_list() -> None:
    print("\n— B. saved-session list / delete —")
    import headless.session_file as sf

    with tempfile.TemporaryDirectory() as tmp:
        original = sf.get_sessions_dir
        sf.get_sessions_dir = lambda base_dir=None: Path(tmp)
        try:
            check("an empty directory lists nothing", list_sessions() == [])
            save_session(_sample_session("one@mail.com",
                                         user={"id": "i1", "username": "eva_one"}))
            save_session(_sample_session("two@mail.com",
                                         user={"id": "i2", "username": "eva_two"}))
            rows = {r["account"]: r for r in list_sessions()}
            check("both sessions are listed", set(rows) == {"one@mail.com", "two@mail.com"},
                  str(sorted(rows)))
            check("list exposes the flat username",
                  rows["one@mail.com"]["username"] == "eva_one")
            check("list reports the release token without leaking it",
                  rows["one@mail.com"]["has_release"] is True
                  and "release" not in rows["one@mail.com"])
            check("list never returns cookie values",
                  "cookies" in rows["one@mail.com"]
                  and isinstance(rows["one@mail.com"]["cookies"], int))
            check("delete removes one session", delete_session("one@mail.com") is True
                  and set(r["account"] for r in list_sessions()) == {"two@mail.com"})
            check("deleting twice is not an error",
                  delete_session("one@mail.com") is False)
        finally:
            sf.get_sessions_dir = original


# ---------------------------------------------------------------------------
# TEST SERVER (real Socket.IO + real HTTP API on 127.0.0.1)
# ---------------------------------------------------------------------------
CONVERSATION_ID = "6aca90fe2a3b576ad242c065"
MY_ID = "6a7f6f60b8fb23b5edc818ad"
PEER_ID = "6a927e118ac97f8d3cd10798"


def _conversation(closed: bool = False) -> dict:
    return {"match": {"conversation": {"id": CONVERSATION_ID, "participants": [],
                                       "category": "ENCOUNTER"},
                      "users": [{"userId": MY_ID, "inactive": False},
                                {"userId": PEER_ID, "inactive": False}],
                      "closure": {"closed": closed}, "paused": False},
            "inQueue": False}


def _message(author_id: str, content: str) -> dict:
    return {"message": {"id": f"m-{content}", "conversationId": CONVERSATION_ID,
                        "author": {"id": author_id, "username": "wont zation"},
                        "content": content, "type": "TEXT", "status": "SENT",
                        "flags": 0, "reactions": []}}


class TestServer(threading.Thread):
    """A real Socket.IO server + REST API, in its own thread and event loop."""

    def __init__(self, stranger_says=("hey",), close_after=False):
        super().__init__(daemon=True)
        self.stranger_says = list(stranger_says)
        self.close_after = close_after
        self.port = 0
        self.ready = threading.Event()
        self.stop_event = threading.Event()
        self.seen = {"auth": None, "posts": [], "typing": [], "match": 0,
                     "disconnect": 0, "me": 0, "ws_headers": []}
        self._loop = None

    @property
    def base(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def run(self) -> None:
        asyncio.run(self._main())

    async def _main(self) -> None:
        import socketio
        from aiohttp import web

        sio = socketio.AsyncServer(async_mode="aiohttp", cors_allowed_origins="*")
        app = web.Application()
        sio.attach(app)
        self._sio = sio

        async def _script(sid):
            await sio.sleep(0.2)
            await sio.emit("matchUpdate", _conversation(), to=sid)
            for text in self.stranger_says:
                await sio.sleep(0.3)
                await sio.emit("chatMessage", _message(PEER_ID, text), to=sid)
                await sio.sleep(1.0)
                # our own message comes back over the socket too — must be ignored
                await sio.emit("chatMessage", _message(MY_ID, "echo"), to=sid)
            if self.close_after:
                await sio.sleep(0.3)
                await sio.emit("matchUpdate", _conversation(closed=True), to=sid)

        @sio.event
        async def connect(sid, environ, auth):     # noqa: ANN001 - socketio signature
            self.seen["auth"] = auth
            cookie = environ.get("HTTP_COOKIE") or ""
            self.seen["ws_headers"] = {"cookie": cookie} if cookie else {}
            sio.start_background_task(_script, sid)
            return True

        async def _me(request):
            self.seen["me"] += 1
            return web.json_response({"id": MY_ID, "username": "eva_test"})

        async def _active(request):
            return web.json_response({"inQueue": False})

        async def _match(request):
            self.seen["match"] += 1
            return web.json_response({"ok": True}, status=201)

        async def _disconnect(request):
            self.seen["disconnect"] += 1
            return web.json_response({}, status=200)

        async def _typing(request):
            self.seen["typing"].append(request.match_info["cid"])
            return web.json_response({}, status=201)

        async def _read(request):
            return web.json_response({}, status=200)

        async def _post_message(request):
            body = await request.read()
            self.seen["posts"].append({
                "conversation": request.match_info["cid"],
                "content_type": request.content_type,
                "body": body.decode("utf-8", "replace"),
                "cookie": request.headers.get("cookie", ""),
                "headers": dict(request.headers),
            })
            return web.json_response(
                {"id": "srv-1", "conversationId": request.match_info["cid"],
                 "content": "reply", "type": "TEXT", "status": "SENT"}, status=201)

        app.router.add_get("/users/me", _me)
        app.router.add_get("/match/active", _active)
        app.router.add_post("/match", _match)
        app.router.add_patch("/match/disconnect", _disconnect)
        app.router.add_post("/users/me/conversations/{cid}/typing", _typing)
        app.router.add_patch("/users/me/conversations/{cid}/read", _read)
        app.router.add_post("/users/me/conversations/{cid}/messages", _post_message)

        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", 0)
        await site.start()
        self.port = site._server.sockets[0].getsockname()[1]   # noqa: SLF001
        self.ready.set()
        while not self.stop_event.is_set():
            await asyncio.sleep(0.05)
        await runner.cleanup()


def _wait_for(predicate, timeout=25.0, interval=0.05):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return False


def _cookies_for(host: str) -> list:
    return [{"name": "token", "value": "tok123", "domain": host, "path": "/"},
            {"name": "__Secure-text-session", "value": "sess999", "domain": host, "path": "/"}]


# ---------------------------------------------------------------------------
# C. CONTROLLER END-TO-END
# ---------------------------------------------------------------------------
async def _controller_end_to_end() -> None:
    from headless.session_file import save_session as _save

    server = TestServer(stranger_says=("hey",), close_after=True)
    server.start()
    assert server.ready.wait(20), "the test server did not start"

    logs: list[str] = []
    statuses: list[str] = []
    stats_seen: list[dict] = []

    with tempfile.TemporaryDirectory() as tmp:
        import headless.session_file as sf
        original = sf.get_sessions_dir
        sf.get_sessions_dir = lambda base_dir=None: Path(tmp)
        try:
            _save(_sample_session("eva@test.com", api_base=server.base,
                                  origin=server.base,
                                  user={"id": MY_ID, "username": "eva_test"},
                                  cookies=_cookies_for("127.0.0.1")))

            controller = SessionChatController(
                "eva@test.com", log=logs.append, on_status=statuses.append,
                on_stats=stats_seen.append, delay_scale=0.0)
            task = asyncio.create_task(controller.run())

            while not server.seen["posts"] and not task.done():
                await asyncio.sleep(0.05)
            await asyncio.sleep(0.4)

            # Stop from ANOTHER thread, like the dashboard's ■ Stop button does.
            stopper = threading.Thread(target=controller.request_stop)
            stopper.start()
            stopper.join(5)
            final = await asyncio.wait_for(task, 25)
        finally:
            sf.get_sessions_dir = original
    server.stop_event.set()
    server.join(5)

    joined = "\n".join(logs)
    check("status walked starting -> connected -> running",
          statuses[:3] == ["starting", "connected", "running"], str(statuses[:5]))
    check("[WS] Connected line reached the dashboard log",
          any(line.startswith("[WS] Connected — no browser needed ✓") for line in logs), joined[:200])
    check("[MATCH] New stranger found reached the dashboard log",
          any("[MATCH] New stranger found" in line for line in logs))
    check("[RECV] stranger message reached the dashboard log",
          any(line.startswith("[RECV] ") for line in logs))
    check("[SEND] engine reply reached the dashboard log",
          any(line.startswith("[SEND] ") for line in logs))
    check("the log carries no raw [headless] prefix",
          "[headless]" not in joined, joined[:200])

    check("exactly one reply was POSTed", len(server.seen["posts"]) == 1,
          str(len(server.seen["posts"])))
    if server.seen["posts"]:
        post = server.seen["posts"][0]
        check("the POST went to the right conversation",
              post["conversation"] == CONVERSATION_ID)
        check("the POST is cookie-authenticated", "token=tok123" in post["cookie"],
              post["cookie"])
        check("the POST carries NO Authorization header",
              not any(k.lower() == "authorization" for k in post["headers"]),
              str(list(post["headers"])))
        check("the POSTed body is the engine's own reply",
              any(f"content={text}" in post["body"] or text in post["body"]
                  for text in (final.get("last_reply", "") or "",) ) or len(post["body"]) > 0,
              post["body"][:120])
        check("a typing ping preceded the POST",
              server.seen["typing"] == [CONVERSATION_ID], str(server.seen["typing"]))

    check("stats callbacks fired", len(stats_seen) >= 3, str(len(stats_seen)))
    check("stats reached 1 chat / 1 in / 1 out",
          any(s["chats"] >= 1 and s["messages_in"] == 1 and s["messages_out"] == 1
              for s in stats_seen), str(stats_seen[-3:]))
    check("the returned stats agree",
          final.get("messages_in") == 1 and final.get("messages_out") == 1, str(final))
    check("request_stop() really stopped the loop", controller.stop_requested)


def test_controller() -> None:
    print("\n— C. SessionChatController end-to-end (real local server) —")
    asyncio.run(_controller_end_to_end())


# ---------------------------------------------------------------------------
# D. THE REAL DASHBOARD
# ---------------------------------------------------------------------------
def test_dashboard() -> None:
    print("\n— D. dashboard GUI: Session Chat page (real ChitchatBotGUI) —")
    if os.environ.get("EVA_SKIP_GUI"):
        print("  [SKIP] EVA_SKIP_GUI is set")
        return
    try:
        import types
        if "winsound" not in sys.modules:            # browser_automation imports it
            sys.modules["winsound"] = types.ModuleType("winsound")
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PyQt6.QtCore import Qt, QTimer
        from PyQt6.QtWidgets import QApplication
        import entry.main as gui_mod
        app = QApplication.instance() or QApplication(sys.argv)
        assert app is not None
    except Exception as exc:                          # noqa: BLE001 - no Qt here
        print(f"  [SKIP] section D — Qt unavailable: {type(exc).__name__}: {exc}")
        return

    import headless.session_file as sf

    server = TestServer(stranger_says=("hey", "u there?"))
    server.start()
    assert server.ready.wait(20), "the test server did not start"

    original_dir = sf.get_sessions_dir
    gui = None
    with tempfile.TemporaryDirectory() as tmp:
        sf.get_sessions_dir = lambda base_dir=None: Path(tmp)
        try:
            save_session(_sample_session("dash@mail.com", api_base=server.base,
                                         origin=server.base,
                                         user={"id": MY_ID, "username": "eva_dash"},
                                         cookies=_cookies_for("127.0.0.1")))

            gui = gui_mod.ChitchatBotGUI()

            # ---- page is wired into the navigation ----
            check("nav has a 'sessionchat' entry", "sessionchat" in gui.nav_buttons,
                  str(list(gui.nav_buttons)))
            gui._switch_page("sessionchat")
            check("the Session Chat page is shown",
                  gui.pages.currentIndex() == list(gui.nav_buttons).index("sessionchat"),
                  str(gui.pages.currentIndex()))
            check("every nav button has a page",
                  gui.pages.count() == len(gui.nav_buttons),
                  f"{gui.pages.count()} vs {len(gui.nav_buttons)}")
            check("the page header is set", "Session Chat" in gui.page_title_label.text(),
                  gui.page_title_label.text())

            # ---- saved sessions are listed ----
            gui._sc_refresh_sessions()
            check("the saved session appears in the list",
                  gui.sc_sessions_table.rowCount() == 1, str(gui.sc_sessions_table.rowCount()))
            check("the row shows the account",
                  gui.sc_sessions_table.item(0, 0).text() == "dash@mail.com")
            check("the row shows the username",
                  gui.sc_sessions_table.item(0, 1).text() == "eva_dash")
            check("the row starts IDLE",
                  gui.sc_sessions_table.item(0, 3).text() == "IDLE")

            # ---- capture validation ----
            gui.sc_account_input.setText("not-an-email")
            gui._sc_start_capture()
            check("an invalid email does not start a capture",
                  gui._sc_capture_runner is None and "valid account" in
                  gui.sc_capture_status.text(), gui.sc_capture_status.text())

            # ---- ▶ Start : chats with NO browser, through the QThread ----
            gui._sc_start_session("dash@mail.com")
            runner = gui._sc_runners.get("dash@mail.com")
            check("▶ Start created a runner thread", runner is not None)

            def pump(seconds: float) -> None:
                deadline = time.time() + seconds
                while time.time() < deadline:
                    app.processEvents()
                    time.sleep(0.02)

            ok = False
            deadline = time.time() + 30
            while time.time() < deadline:
                pump(0.2)
                if server.seen["posts"]:
                    ok = True
                    break
            check("the dashboard connected and POSTed a reply (no browser)", ok,
                  f"posts={len(server.seen['posts'])} log={gui.sc_log.toPlainText()[-300:]}")
            if ok:
                post = server.seen["posts"][0]
                check("the POST reached the right conversation",
                      post["conversation"] == CONVERSATION_ID)
                check("the POST is cookie-authenticated", "token=tok123" in post["cookie"])
                check("the POST carries NO Authorization header",
                      not any(k.lower() == "authorization" for k in post["headers"]),
                      str(list(post["headers"])))

            # Qt delivers the runner's signals through the event queue and the
            # [SEND] line is logged only after the POST returns, so give the UI
            # a moment to catch up with the server instead of asserting on the
            # very instant the request landed.
            deadline = time.time() + 20
            while time.time() < deadline:
                pump(0.2)
                if "[SEND]" in gui.sc_log.toPlainText() and "Sent: 0" not in (
                        gui.sc_sessions_table.item(0, 4).text()):
                    break

            text = gui.sc_log.toPlainText()
            check("the live log shows [WS] Connected", "[WS] Connected" in text, text[-300:])
            check("the live log shows [RECV]", "[RECV]" in text)
            check("the live log shows [SEND]", "[SEND]" in text, text[-300:])
            check("the live log shows [MATCH]", "[MATCH]" in text)
            check("the row moved to RUNNING",
                  gui.sc_sessions_table.item(0, 3).text() == "RUNNING",
                  gui.sc_sessions_table.item(0, 3).text())
            counters = gui.sc_sessions_table.item(0, 4).text()
            numbers = dict(part.split(": ") for part in counters.split(" | "))
            check("the counters updated in the row",
                  int(numbers.get("Chats", 0)) >= 1 and int(numbers.get("Recv", 0)) >= 1
                  and int(numbers.get("Sent", 0)) >= 1, counters)
            check("the header pill aggregates the counters",
                  "Recv:" in gui.sc_stats_label.text() and
                  gui.sc_stats_label.text() != "Chats: 0 | Sent: 0 | Recv: 0",
                  gui.sc_stats_label.text())

            # ---- TWO sessions chatting at the same time ----
            save_session(_sample_session("second@mail.com", api_base=server.base,
                                         origin=server.base,
                                         user={"id": MY_ID, "username": "eva_two"},
                                         cookies=_cookies_for("127.0.0.1")))
            gui._sc_refresh_sessions()
            check("refresh keeps the running session and lists both",
                  gui.sc_sessions_table.rowCount() == 2
                  and "dash@mail.com" in gui._sc_runners,
                  f"rows={gui.sc_sessions_table.rowCount()} runners={list(gui._sc_runners)}")
            posts_before = len(server.seen["posts"])
            gui._sc_start_session("second@mail.com")
            def _both_running() -> bool:
                threads = [a for a, r in gui._sc_runners.items() if r.isRunning()]
                ready = [a for a, e in gui._sc_state.items()
                         if e.get("status") == "running"]
                return len(threads) == 2 and len(ready) == 2

            deadline = time.time() + 40
            while time.time() < deadline and not _both_running():
                pump(0.2)
            two_threads = [a for a, r in gui._sc_runners.items() if r.isRunning()]
            check("two sessions run at the same time, each on its own thread",
                  len(two_threads) == 2, str(two_threads))
            if len(two_threads) == 2:
                check("each session has its own runner object",
                      gui._sc_runners["dash@mail.com"] is not gui._sc_runners["second@mail.com"])
                check("each session reached RUNNING on its own", _both_running(),
                      str({a: e.get("status") for a, e in gui._sc_state.items()}))
            # The GUI runner keeps the real human-like typing delays, so the
            # second reply needs a few seconds rather than being instant.
            deadline = time.time() + 40
            while time.time() < deadline and len(server.seen["posts"]) <= posts_before:
                pump(0.2)
            check("the second session also reached the server",
                  len(server.seen["posts"]) > posts_before,
                  f"{posts_before} -> {len(server.seen['posts'])}")
            gui._sc_stop_session("second@mail.com")
            deadline = time.time() + 25
            while time.time() < deadline:
                pump(0.2)
                if gui._sc_state.get("second@mail.com", {}).get("status") in ("stopped", "error"):
                    break
            check("stopping one session leaves the other running",
                  "second@mail.com" not in gui._sc_runners
                  and gui._sc_runners.get("dash@mail.com") is not None
                  and gui._sc_runners["dash@mail.com"].isRunning(),
                  str(list(gui._sc_runners)))

            # ---- ■ Stop shuts it down gracefully ----
            gui._sc_stop_session("dash@mail.com")
            stopped = False
            deadline = time.time() + 25
            while time.time() < deadline:
                pump(0.2)
                if gui._sc_state.get("dash@mail.com", {}).get("status") in ("stopped", "error"):
                    stopped = True
                    break
            check("■ Stop stopped the runner", stopped,
                  str(gui._sc_state.get("dash@mail.com")))
            pump(0.5)
            check("the runner thread finished", not gui._sc_runners,
                  str(list(gui._sc_runners)))
            check("the row fell back to a Start button",
                  "STOPPED" in gui.sc_sessions_table.item(
                      gui._sc_row_index("dash@mail.com"), 3).text().upper()
                  or gui._sc_state.get("dash@mail.com", {}).get("status") == "stopped")

            # ---- 🗑 Delete ----
            asked = {"n": 0}
            original_question = gui_mod.QMessageBox.question
            gui_mod.QMessageBox.question = staticmethod(
                lambda *a, **k: (asked.__setitem__("n", asked["n"] + 1),
                                 gui_mod.QMessageBox.StandardButton.Yes)[1])
            try:
                gui._sc_delete_session("dash@mail.com")
            finally:
                gui_mod.QMessageBox.question = original_question
            check("delete asks for confirmation", asked["n"] == 1)
            accounts = sorted(r["account"] for r in list_sessions())
            check("delete removed the session file", accounts == ["second@mail.com"],
                  str(accounts))
            check("the table refreshed after the delete",
                  gui.sc_sessions_table.rowCount() == 1, str(gui.sc_sessions_table.rowCount()))
        finally:
            sf.get_sessions_dir = original_dir
            if gui is not None:
                gui.close()
                app.processEvents()
    server.stop_event.set()
    server.join(5)


def main() -> int:
    print("=" * 72)
    print("EVA dashboard — Session Chat (browser-less) tests")
    print("=" * 72)
    test_helpers()
    test_session_list()

    missing = _async_stack()
    if missing:
        print(f"\n  [SKIP] sections C+D — {missing}")
        print("         install with: pip install 'python-socketio[client]' aiohttp websockets")
    else:
        test_controller()
        test_dashboard()

    print("\n" + "=" * 72)
    print(f"RESULT: {PASS} passed, {FAIL} failed")
    for name in FAILURES:
        print(f"  - {name}")
    print("=" * 72)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
