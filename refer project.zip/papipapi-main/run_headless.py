#!/usr/bin/env python3
"""run_headless.py — EVA bot with NO browser open.

    python run_headless.py --capture --account me@mail.com   # ONE browser run
    python run_headless.py --check     --account me@mail.com # is the session alive?
    python run_headless.py --run       --account me@mail.com # chat, browserless
    python run_headless.py --list                            # saved sessions
    python run_headless.py --probe     --account me@mail.com --conversation <id>

``--capture`` is the only step that needs a browser (and Playwright).  It saves
the cookies plus the Socket.IO ``release`` token, and every later run connects
straight to ``wss://api.chitchat.gg/socket.io/`` — incoming text arrives as the
``chatMessage`` event, outgoing text is POSTed to
``/users/me/conversations/{id}/messages``.

Requires:  pip install 'python-socketio[client]' aiohttp websockets
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from headless.session_file import (          # noqa: E402
    SessionError,
    delete_session,
    list_sessions,
    load_session,
)


def _log(message: str) -> None:
    print(message, flush=True)


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------

def cmd_list(_args) -> int:
    sessions = list_sessions()
    if not sessions:
        print("No saved headless sessions. Run: python run_headless.py --capture")
        return 0
    print(f"{'account':<32} {'username':<20} {'cookies':>7}  release  created")
    for item in sessions:
        print(f"{str(item.get('account') or '')[:32]:<32} "
              f"{str(item.get('username') or '-')[:20]:<20} "
              f"{item.get('cookies', 0):>7}  "
              f"{'yes' if item.get('has_release') else 'NO ':<7}  "
              f"{item.get('created') or '-'}")
    return 0


async def _cmd_capture(args) -> int:
    from headless.capture import capture_session
    session = await capture_session(
        account=args.account,
        start_url=args.url,
        headed=not args.headless,
        storage_state=args.storage_state,
        wait_seconds=args.wait,
        api_base=args.api_base,
        log=_log,
    )
    print(f"\nSaved: account={session.account} user={session.username or '?'} "
          f"cookies={len(session.cookies)} release={len(session.release)} chars")
    print(f"Now run without a browser:\n  python run_headless.py --run --account {session.account}")
    return 0


async def _cmd_check(args) -> int:
    from headless.api import ApiError, ChitchatAPI
    session = _load(args)
    print(f"session : {session.account}  (created {session.created or '?'})")
    print(f"api base: {session.api_base}")
    print(f"ws url  : {session.ws_endpoint}")
    print(f"cookies : {len(session.cookies)} -> {', '.join(session.cookie_names()[:8])}")
    missing = session.missing_auth_cookies()
    if missing:
        print(f"WARNING : expected login cookies missing: {missing}")
    async with ChitchatAPI(session, log=_log) as api:
        try:
            me = await api.me()
        except ApiError as exc:
            if exc.status == 0:
                print(f"GET /users/me could not reach {session.api_base}: {exc.body[:160]}")
                print("-> check the network / api base, not the session")
            else:
                print(f"GET /users/me FAILED: {exc.status} {exc.body[:160]}")
                print("-> the session is expired; re-run --capture")
            return 1
        print(f"me      : id={me.get('id')} username={me.get('username')} "
              f"verified={me.get('verified')}")
        try:
            standing = await api.moderation_standing()
            print(f"standing: {standing.get('standing')} "
                  f"limited={standing.get('limitedFeatures')}")
        except ApiError as exc:
            print(f"standing: unavailable ({exc.status})")
        print(f"banned  : {await api.is_banned()}")
    return 0


async def _cmd_probe(args) -> int:
    from headless.api import ChitchatAPI
    session = _load(args)
    if not args.conversation:
        print("--probe needs --conversation <id> (from a live chat or matchUpdate)")
        return 2
    async with ChitchatAPI(session, log=_log) as api:
        report = await api.probe_send_mode(args.conversation)
    print(json.dumps(report, indent=2))
    accepted = [mode for mode, result in report.items() if result == "accepted"]
    if accepted:
        print(f"\nThe server accepted: {', '.join(accepted)}")
        print(f"Pin it with:  HEADLESS_MESSAGE_MODE={accepted[0]}")
        return 0
    print("\nNeither encoding was accepted — paste the output above and check "
          "whether the session is still valid (--check).")
    return 1


async def _cmd_run(args) -> int:
    from headless.api import ChitchatAPI
    from headless.client import ConnectError, HeadlessChatClient
    from headless.worker import HeadlessWorker

    session = _load(args)
    message_mode = os.environ.get("HEADLESS_MESSAGE_MODE", "auto")

    client = HeadlessChatClient(session, log=_log, presence_interval=args.presence)
    api = ChitchatAPI(session, log=_log, message_mode=message_mode)

    stopping = False

    def _request_stop(*_exc):
        nonlocal stopping
        if stopping:
            return
        stopping = True
        print("\n[headless] stopping after the current message…")
        worker.stop()

    for signal_name in ("SIGINT", "SIGTERM"):
        try:
            import signal
            signal.signal(getattr(signal, signal_name), _request_stop)
        except (ValueError, AttributeError, OSError):
            pass                        # not on the main thread / not on Windows

    await api.start()
    worker = HeadlessWorker(client, api, log=_log,
                            with_interests=args.with_interests,
                            auto_next=not args.no_auto_next)
    try:
        print(f"[headless] connecting to {session.ws_endpoint}")
        await client.connect(timeout=args.connect_timeout)
        print(f"[headless] connected (heartbeat every {client.ping_interval * 1000:.0f} ms)")
        await worker.start()
        if not args.no_match:
            await worker.ensure_match()
        stats = await worker.run()
    except ConnectError as exc:
        print(f"[headless] CONNECT failed: {exc}")
        print("-> if the release token was rejected, re-run: "
              f"python run_headless.py --capture --account {session.account}")
        return 1
    except RuntimeError as exc:
        print(f"[headless] {exc}")
        return 1
    finally:
        await client.disconnect()
        await api.close()

    print("\n" + json.dumps(stats, indent=2, default=str))
    return 0


# ---------------------------------------------------------------------------

def _load(args):
    try:
        return load_session(account=args.account, path=args.session)
    except SessionError as exc:
        raise SystemExit(f"{exc}\n\nCapture one with: "
                         f"python run_headless.py --capture --account <email>")


COMMANDS = {
    "capture": _cmd_capture,
    "check": _cmd_check,
    "run": _cmd_run,
    "probe": _cmd_probe,
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="EVA bot, browserless: Socket.IO in, HTTP POST out.")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--capture", action="store_true",
                      help="the ONE browser run: save cookies + release token")
    mode.add_argument("--run", action="store_true",
                      help="chat with strangers with no browser open")
    mode.add_argument("--check", action="store_true",
                      help="verify a saved session against the API")
    mode.add_argument("--probe", action="store_true",
                      help="find out which message encoding the API accepts")
    mode.add_argument("--list", action="store_true", help="list saved sessions")
    mode.add_argument("--delete", metavar="ACCOUNT", help="delete a saved session")

    parser.add_argument("--account", help="account email used at capture time")
    parser.add_argument("--session", help="explicit session JSON path")
    parser.add_argument("--url", default="https://app.chitchat.gg/start/new",
                        help="page to open for --capture")
    parser.add_argument("--storage-state", help="Playwright storage_state.json to reuse")
    parser.add_argument("--headless", action="store_true",
                        help="capture without a visible window (you must already be logged in)")
    parser.add_argument("--wait", type=float, default=240.0,
                        help="seconds to wait for the chat socket during capture")
    parser.add_argument("--api-base", default="",
                        help="override the API origin (default: taken from the websocket URL)")
    parser.add_argument("--conversation", help="conversation id for --probe")
    parser.add_argument("--presence", type=float, default=0.0,
                        help="emit presenceSync every N seconds (0 = never)")
    parser.add_argument("--with-interests", action="store_true",
                        help="POST /match with withInterests=true")
    parser.add_argument("--no-auto-next", action="store_true",
                        help="stop after the first chat instead of queueing the next")
    parser.add_argument("--no-match", action="store_true",
                        help="do not queue a match on start (listen only)")
    parser.add_argument("--connect-timeout", type=float, default=30.0)
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.list:
        return cmd_list(args)
    if args.delete:
        return 0 if delete_session(args.delete) else 1
    if not (args.account or args.session):
        print("Pass --account <email> (the one used with --capture) or --session <path>")
        return 2
    command = ("capture" if args.capture else "check" if args.check
               else "probe" if args.probe else "run")
    try:
        return asyncio.run(COMMANDS[command](args))
    except ImportError as exc:
        print(f"{exc}")
        print("Install the browserless dependencies with:")
        print('  pip install "python-socketio[client]" aiohttp websockets')
        return 2
    except KeyboardInterrupt:
        print("\ninterrupted")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
