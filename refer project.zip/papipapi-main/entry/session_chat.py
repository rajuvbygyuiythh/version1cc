"""
Dashboard glue for the browser-less (WebSocket) chat mode.

Two responsibilities, deliberately split so both can be tested:

1. **Pure helpers** — log tagging, session-row formatting, subprocess command
   building.  No Qt, no asyncio, no network.
2. **Runners** — :class:`SessionChatController` (plain asyncio, runs one saved
   session until stopped) plus thin ``QThread`` wrappers that only exist when
   PyQt6 is importable.

The chat engine is untouched: ``headless.worker.HeadlessWorker`` builds the very
same ``chat.rule_bot.ChatRuleBot`` the browser bot uses, and replies still leave
over ``POST /users/me/conversations/{id}/messages`` — never over the socket.
"""

from __future__ import annotations

import asyncio
import datetime
import os
import re
import subprocess
import sys
import threading
from typing import Any, Callable, Dict, List, Optional

# PyQt6 is optional at import time so the pure helpers stay testable (and the
# module stays importable from the CLI) on machines without it.
try:                                            # pragma: no cover - env dependent
    from PyQt6.QtCore import QThread, pyqtSignal
    HAS_QT = True
except ImportError:                             # pragma: no cover
    QThread = object                            # type: ignore[assignment]
    HAS_QT = False

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---------------------------------------------------------------------------
# PURE HELPERS
# ---------------------------------------------------------------------------
# The worker's own log text -> the dashboard's tagged format.
_SEND_RE = re.compile(r"^\s*eva> (.*)$")
_RECV_RE = re.compile(r"^\s*(.+?)> (.*)$")
_CHAT_START_RE = re.compile(r"^\[headless\] chat #(\d+) started")
_CHAT_END_RE = re.compile(r"^\[headless\] chat #(\d+) ended \((.+?)\)")
_LOGIN_RE = re.compile(r"^\[headless\] logged in as (.+?) \(id=")


def decorate_log(line: str) -> str:
    """Re-tag one worker log line for the dashboard feed.

    ``headless.worker`` keeps its own wording (and its tests depend on it), so
    the translation for the UI lives here instead.
    """
    text = str(line).rstrip("\n")

    if _LOGIN_RE.match(text):
        who = _LOGIN_RE.match(text).group(1)
        return f"[WS] Connected — no browser needed ✓  (logged in as {who})"

    match = _CHAT_START_RE.match(text)
    if match:
        return f"[MATCH] New stranger found (chat #{match.group(1)})"

    match = _CHAT_END_RE.match(text)
    if match:
        return (f"[MATCH] Conversation closed → next stranger "
                f"({match.group(2)})")

    match = _SEND_RE.match(text)
    if match:
        return f"[SEND] {match.group(1)}"

    match = _RECV_RE.match(text)
    if match:
        return f"[RECV] {match.group(1)}> {match.group(2)}"

    if "[headless] queued for the next stranger" in text or "in the match queue" in text:
        return "[MATCH] Queued for the next stranger"
    if "[headless] backing off" in text:
        return "[WAIT] " + text.split("[headless] ", 1)[-1]
    if "API error" in text or "error" in text.lower():
        return "[ERROR] " + text.split("[headless] ", 1)[-1]
    if text.startswith("[headless] "):
        return text[len("[headless] "):]
    return text


def relative_time(created: Any, now: Optional[datetime.datetime] = None) -> str:
    """``2h ago`` / ``1d ago`` for a saved session, tolerant of odd formats."""
    if not created:
        return "unknown"
    now = now or datetime.datetime.now()
    stamp = str(created)
    parsed: Optional[datetime.datetime] = None
    for candidate in (stamp, stamp.replace("Z", "+00:00")):
        try:
            parsed = datetime.datetime.fromisoformat(candidate)
            break
        except ValueError:
            continue
    if parsed is None:
        return stamp
    if parsed.tzinfo is not None:
        now = now.astimezone(parsed.tzinfo)
    seconds = max(0, int((now - parsed).total_seconds()))
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h ago"
    return f"{seconds // 86400}d ago"


def format_stats(stats: Optional[Dict[str, Any]]) -> str:
    """One-line counter summary, e.g. ``Chats: 12 | Sent: 47 | Recv: 31``."""
    if not stats:
        return "Chats: 0 | Sent: 0 | Recv: 0"
    return (f"Chats: {stats.get('chats', 0)} | "
            f"Sent: {stats.get('messages_out', 0)} | "
            f"Recv: {stats.get('messages_in', 0)}")


def session_row(info: Dict[str, Any], now: Optional[datetime.datetime] = None) -> Dict[str, Any]:
    """Normalise one :func:`headless.session_file.list_sessions` entry for a row.

    ``list_sessions`` flattens the username to ``info["username"]`` (there is no
    nested ``user`` dict), so this is the single place that reads its shape.
    """
    account = info.get("account") or "?"
    return {
        "account": account,
        "username": info.get("username") or "unknown",
        "created": info.get("created"),
        "saved": relative_time(info.get("created"), now),
        "cookies": info.get("cookies") or 0,
        "has_release": bool(info.get("has_release")),
        "file": info.get("file"),
        "usable": bool(info.get("has_release")) and bool(info.get("cookies")),
    }


def build_capture_command(account: str,
                          python_exe: Optional[str] = None,
                          start_url: str = "",
                          headed: bool = True,
                          wait_seconds: float = 0.0,
                          extra_args: Optional[List[str]] = None) -> List[str]:
    """``python run_headless.py --capture --account <email>`` as an argv list.

    Capture needs a real browser, so it runs in its own process; the dashboard
    only has to watch its output.
    """
    if not account or not account.strip():
        raise ValueError("an account email is required")
    cmd = [python_exe or sys.executable, "run_headless.py", "--capture",
           "--account", account.strip()]
    if start_url:
        cmd += ["--url", start_url]
    if not headed:
        cmd += ["--headless"]
    if wait_seconds:
        cmd += ["--wait", str(wait_seconds)]
    cmd += list(extra_args or ())
    return cmd


def build_run_command(account: str, python_exe: Optional[str] = None,
                      extra_args: Optional[List[str]] = None) -> List[str]:
    """The CLI equivalent of :class:`SessionChatController` (for parity/debug)."""
    cmd = [python_exe or sys.executable, "run_headless.py", "--run",
           "--account", account.strip()]
    cmd += list(extra_args or ())
    return cmd


# ---------------------------------------------------------------------------
# THE RUNNER CORE (plain asyncio — no Qt)
# ---------------------------------------------------------------------------
class SessionChatController:
    """Runs ONE saved session on the websocket until :meth:`request_stop`.

    Everything the dashboard needs to show (log lines, status, counters) is
    pushed out through the three callbacks, so this class never imports Qt and
    can be driven straight from a test.
    """

    def __init__(self,
                 account: str,
                 log: Optional[Callable[[str], None]] = None,
                 on_status: Optional[Callable[[str], None]] = None,
                 on_stats: Optional[Callable[[Dict[str, Any]], None]] = None,
                 session_path: Optional[str] = None,
                 message_mode: str = "auto",
                 with_interests: bool = False,
                 auto_next: bool = True,
                 mark_read: bool = True,
                 start_match: bool = True,
                 presence: float = 0.0,
                 connect_timeout: float = 30.0,
                 delay_scale: float = 1.0,
                 raw_log: bool = False) -> None:
        self.account = account
        self.session_path = session_path
        self.message_mode = message_mode
        self.with_interests = with_interests
        self.auto_next = auto_next
        self.mark_read = mark_read
        self.start_match = start_match
        self.presence = presence
        self.connect_timeout = connect_timeout
        self.delay_scale = delay_scale
        self.raw_log = raw_log

        self._log_cb = log or (lambda _m: None)
        self._status_cb = on_status or (lambda _s: None)
        self._stats_cb = on_stats
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._stop_requested = threading.Event()
        self.worker: Any = None
        self.client: Any = None
        self.status = "idle"
        self.last_stats: Dict[str, Any] = {}

    # -- callbacks into the UI -------------------------------------------
    def _log(self, message: str) -> None:
        self._log_cb(message if self.raw_log else decorate_log(message))

    def _status(self, status: str) -> None:
        self.status = status
        self._status_cb(status)

    def _stats(self, stats: Dict[str, Any]) -> None:
        self.last_stats = stats
        if self._stats_cb is not None:
            self._stats_cb(stats)

    # -- control ----------------------------------------------------------
    def request_stop(self) -> None:
        """Ask the loop to finish the current message and return.

        Safe to call from the GUI thread: ``asyncio.Event.set`` is not
        thread-safe, so the flag is set through the running loop.
        """
        self._stop_requested.set()
        worker, loop = self.worker, self._loop
        if worker is None or loop is None:
            return
        try:
            loop.call_soon_threadsafe(worker.stop)
        except RuntimeError:                       # loop already closed
            worker.stop()

    @property
    def stop_requested(self) -> bool:
        return self._stop_requested.is_set()

    # -- the actual run ---------------------------------------------------
    async def run(self) -> Dict[str, Any]:
        from headless.api import ChitchatAPI
        from headless.client import HeadlessChatClient
        from headless.session_file import load_session
        from headless.worker import HeadlessWorker

        self._loop = asyncio.get_running_loop()
        self._status("starting")

        session = load_session(account=self.account, path=self.session_path)
        self._log(f"[SESSION] loaded for {session.account} "
                  f"({len(session.cookies)} cookies, release {len(session.release)} chars)")

        client = HeadlessChatClient(session, log=self._log,
                                    presence_interval=self.presence)
        self.client = client
        stats: Dict[str, Any] = {}
        try:
            async with ChitchatAPI(session, log=self._log,
                                   message_mode=self.message_mode) as api:
                worker = HeadlessWorker(
                    client, api, log=self._log,
                    with_interests=self.with_interests,
                    auto_next=self.auto_next,
                    mark_read=self.mark_read,
                    delay_scale=self.delay_scale,
                    on_stats=self._stats,
                )
                self.worker = worker
                if self.stop_requested:            # stopped before we got going
                    worker.stop()

                self._log(f"[WS] connecting to {session.ws_endpoint}")
                await client.connect(timeout=self.connect_timeout)
                self._status("connected")
                await worker.start()
                if self.start_match:
                    await worker.ensure_match()
                self._status("running")
                stats = await worker.run()
        finally:
            await client.disconnect()
            self.worker = None
            self.client = None
        return stats


# ---------------------------------------------------------------------------
# QTHREAD WRAPPERS (only defined when PyQt6 is importable)
# ---------------------------------------------------------------------------
if HAS_QT:                                        # pragma: no cover - needs Qt

    class SessionChatRunner(QThread):
        """Drives :class:`SessionChatController` on its own thread."""

        log_signal = pyqtSignal(str)
        status_signal = pyqtSignal(str)
        stats_signal = pyqtSignal(dict)

        def __init__(self, account: str, parent=None, **controller_kwargs):
            super().__init__(parent)
            self.account = account
            self._kwargs = controller_kwargs
            self.controller: Optional[SessionChatController] = None

        def run(self) -> None:                    # noqa: D102 - QThread hook
            self.controller = SessionChatController(
                self.account,
                log=self.log_signal.emit,
                on_status=self.status_signal.emit,
                on_stats=self.stats_signal.emit,
                **self._kwargs,
            )
            try:
                stats = asyncio.run(self.controller.run())
                self.stats_signal.emit(stats or {})
                self.status_signal.emit("stopped")
            except Exception as exc:              # noqa: BLE001 - report to UI
                self.log_signal.emit(f"[ERROR] {type(exc).__name__}: {exc}")
                self.status_signal.emit("error")

        def stop(self) -> None:
            if self.controller is not None:
                self.controller.request_stop()

    class SessionCaptureRunner(QThread):
        """Runs ``run_headless.py --capture`` as a subprocess, streaming output."""

        log_signal = pyqtSignal(str)
        result_signal = pyqtSignal(bool, str)

        def __init__(self, account: str, parent=None, **command_kwargs):
            super().__init__(parent)
            self.account = account
            self._kwargs = command_kwargs
            self._proc: Optional[subprocess.Popen] = None

        def run(self) -> None:                    # noqa: D102 - QThread hook
            try:
                cmd = build_capture_command(self.account, **self._kwargs)
            except ValueError as exc:
                self.log_signal.emit(f"[ERROR] {exc}")
                self.result_signal.emit(False, str(exc))
                return
            self.log_signal.emit("[CAPTURE] " + " ".join(cmd))
            try:
                self._proc = subprocess.Popen(
                    cmd, cwd=ROOT_DIR, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True,
                    encoding="utf-8", errors="replace",
                )
            except OSError as exc:
                self.log_signal.emit(f"[ERROR] cannot start the capture: {exc}")
                self.result_signal.emit(False, str(exc))
                return
            assert self._proc.stdout is not None
            for line in self._proc.stdout:
                if line.strip():
                    self.log_signal.emit(decorate_log(line.rstrip()))
            code = self._proc.wait()
            ok = code == 0
            self.result_signal.emit(
                ok, "session saved" if ok else f"capture exited with code {code}")

        def stop(self) -> None:
            if self._proc is not None and self._proc.poll() is None:
                self._proc.terminate()
