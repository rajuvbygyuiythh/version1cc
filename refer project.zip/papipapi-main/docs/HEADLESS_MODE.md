# Headless mode — chat with NO browser open

One browser run saves the session. Every run after that talks to chitchat.gg
directly over the Socket.IO websocket, and no browser process exists at all.

```
   ONCE                                EVERY RUN AFTER
┌───────────────┐                 ┌──────────────────────────────────────────┐
│  --capture    │  cookies +      │  wss://api.chitchat.gg/socket.io/        │
│  (Playwright) │──release token─▶│    40{"release":"<hash>"}   <- CONNECT   │
└───────────────┘   saved to      │    42["chatMessage",{…}]    <- receive   │
                  headless_       │    2 / 3                    <- heartbeat │
                  sessions/*.json │                                          │
                                  │  POST /users/me/conversations/{id}/      │
                                  │       messages              -> send      │
                                  └──────────────────────────────────────────┘
```

## Facts this is built on (capture `session_20261011_012346`)

| Item | Value |
|---|---|
| WS endpoint | `wss://api.chitchat.gg/socket.io/?EIO=4&transport=websocket` |
| Protocol | Engine.IO v4 / Socket.IO — **not** a raw websocket |
| CONNECT auth | `40{"release":"<hash>"}` |
| Receive | Socket.IO event `chatMessage` (60 seen), `matchUpdate` (12), `typing` (32), `messageEdited` (4), `onlineFriends` (22) |
| Send | `POST /users/me/conversations/{id}/messages` → 201 |
| Typing | `POST /users/me/conversations/{id}/typing` → 201 |
| Read receipt | `PATCH /users/me/conversations/{id}/read` → 200 |
| Match | `POST /match` `{"withInterests":bool}` → 201 (403 once) |
| Next stranger | `PATCH /match/disconnect` → 200 |
| Identity | `GET /users/me` → `{id, username, …}` |
| Auth | cookies only (`token`, `__Secure-text-session`) — **no `Authorization` header on any request** |
| Heartbeat | 25 000 ms, negotiated by the Engine.IO handshake |

Dead ends, deliberately not implemented:

* raw `websockets.connect()` — no Engine.IO handshake, no frames. The client
  must speak `0{…}` open, `2`/`3` ping/pong, `40{…}` connect, `42[…]` events.
  `python-socketio` does exactly this, so `headless/client.py` wraps it.
* sending chat text over the socket — the site POSTs it.
* a Bearer/`Authorization` header — the capture shows cookie auth only.

## Install

```bat
pip install "python-socketio[client]" aiohttp websockets
```
(added to `data/requirements.txt`)

## Use

```bash
# 1. ONE browser run — log in, the release token is lifted from the site's
#    own websocket CONNECT frame (so we never guess where the site keeps it)
python run_headless.py --capture --account me@mail.com

# 2. check the saved session (no browser, no chat)
python run_headless.py --check --account me@mail.com

# 3. chat with strangers — browserless
python run_headless.py --run   --account me@mail.com

# other
python run_headless.py --list
python run_headless.py --probe --account me@mail.com --conversation <id>
```

Useful flags for `--run`: `--no-auto-next` (stop after one chat), `--no-match`
(listen only), `--presence 30` (emit `presenceSync` every 30 s, as the site's
own client does), `--with-interests`.

## From the dashboard — the 🔌 Session Chat page

The CLI is not the only way in. `entry/main.py` has a **Session Chat** page that
drives the same stack, and `entry/session_chat.py` holds the glue:

| Piece | What it does |
|---|---|
| `SessionChatController` | plain `asyncio` — loads the session, connects, runs the worker until stopped. **No Qt**, so it is testable on its own |
| `SessionChatRunner(QThread)` | one thread per account; emits `log_signal`, `status_signal`, `stats_signal`. Defined only when PyQt6 imports |
| `SessionCaptureRunner(QThread)` | runs `run_headless.py --capture` as a subprocess and streams its output into the dashboard log |
| `decorate_log()` | turns the worker's own log text into the tagged feed (`[WS]` / `[MATCH]` / `[RECV]` / `[SEND]`); the worker's wording is left alone |

Flow in the UI:

1. **🌐 Start Browser** → the one-time capture subprocess → `✅ Session saved`.
2. **Saved Sessions** lists every file in `headless_sessions/` (account,
   username, `2h ago`).
3. **▶ Start** on a row → connects with no browser → chats. **■ Stop** finishes
   the current message and shuts down; the row falls back to ▶ Start.
4. Several accounts can run at the same time — each row gets its own thread and
   its own `Chats | Sent | Recv` counters, plus an aggregate pill in the header.
5. **🗑** asks for confirmation, then deletes the session file.

`headless/worker.py` gained exactly one additive thing for this: an optional
`on_stats` callback. If a UI callback raises, it is disabled rather than allowed
to break the chat loop. Nothing else in the engine changed — the dashboard runs
the same `ChatRuleBot` and the same `data/output/*.txt` pools.

## Where the `release` token comes from

It is not in any documented place, so the capture does not look for it — it
**watches the site's own websocket** with
`page.on("websocket")` → `ws.on("framesent")` and reads the auth straight out
of the CONNECT frame:

```
40{"release":"9f2c1ab7d4e5"}
```

`headless/capture.py::parse_connect_frame` also handles the namespaced form
`40/ns,{"release":…}` and ignores Engine.IO control frames. That keeps working
no matter which bundle, localStorage key or API response originally held it.

The API origin is taken from the websocket URL that was actually opened, so a
change from `api.chitchat.gg` to something else is picked up automatically
(`--api-base` overrides it).

## Message encoding — the one open question

The capture recorded the send body as an opaque `_multipart_raw` blob; the tool
did not decode the form fields. So the *transport* is form based but the *field
name* is unconfirmed. `ChitchatAPI.send_message` implements three encodings:

| mode | content type |
|---|---|
| `form` | `application/x-www-form-urlencoded` |
| `multipart` | `multipart/form-data` |
| `json` | `application/json` |

`HEADLESS_MESSAGE_MODE=auto` (default) walks `form → multipart → json` on the
first send and then sticks with whatever the server accepted. Pin one with
`HEADLESS_MESSAGE_MODE=form`, and change the field name with
`HEADLESS_MESSAGE_FIELD` (default `content`). `--probe` posts a test message
each way and prints which the server accepted.

## Layout

```
headless/
├── session_file.py   cookies + release token, 0600, cookie scoping
├── capture.py        the ONE browser run (frame/URL parsing is pure + tested)
├── api.py            aiohttp REST client — cookies only, three send encodings
├── client.py         Socket.IO wrapper: auth payload, event routing, heartbeat
└── worker.py         matchUpdate → ChatRuleBot → POST reply → next stranger
run_headless.py       CLI: --capture --check --run --probe --list --delete
entry/session_chat.py dashboard glue: log tags, session rows, QThread runners
entry/main.py         🔌 Session Chat page (capture, session list, live log)
tests/test_headless_client.py   50 offline checks incl. a real local Socket.IO server
tests/test_session_chat.py      81 checks incl. the real GUI chatting end to end
```

The worker reuses `chat/rule_bot.py`, so replies come from the same
`data/input/` + `data/output/` pools as the browser bot, and the same
under-18 snap block applies. Nothing in `headless/` imports PyQt6, so it runs
on a machine with no display.

## Verified / not verified

`python tests/test_headless_client.py` → **50 passed, 0 failed**. Section D
starts a **real** Socket.IO server and a real HTTP API on 127.0.0.1 and drives
the actual client + worker:

* the CONNECT frame really carries `{"release": …}` (asserted server-side);
* the Engine.IO heartbeat is negotiated;
* `chatMessage` from the peer produces exactly one `POST …/messages`;
* our own `chatMessage` echo (`author.id == /users/me id`) is not answered;
* the send is authenticated by cookies and carries no `Authorization` header;
* a `matchUpdate` with `closure.closed` disconnects and queues the next match.

`python tests/test_session_chat.py` → **81 passed, 0 failed**. Its section D
builds the **real** `ChitchatBotGUI` offscreen, presses ▶ Start through the
`QThread` runner and asserts against a real local Socket.IO server that the
engine's reply arrived as a cookie-authenticated `POST` with no `Authorization`
header, that the live log shows `[WS]`/`[MATCH]`/`[RECV]`/`[SEND]`, that the row
counters moved, and that **■ Stop** shuts the thread down. Section C does the
same at controller level and stops it from a second thread. The suite degrades:
32 checks without the socket.io deps, 48 without Qt.

**Not verified:** anything against the real `api.chitchat.gg`. This sandbox has
no route to it, so the release-token acceptance, the exact send encoding, and
`presenceSync`'s real payload shape are all still to be confirmed on a live
run — start with `--check`, then `--probe`.

## Safety notes

* `headless_sessions/` holds live cookies and is gitignored; files are written
  `0600`. Never commit or share them.
* A 403 from `POST /match` is treated as rate limiting: the worker backs off
  2 s → 4 s → 8 s … up to 120 s. The capture showed one 403 while
  `/moderation/ban` was 404 and `/moderation/standing` was clean.
* `--capture` needs a display and a real login. `--run` never opens a browser.
