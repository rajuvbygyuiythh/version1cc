# AGENTS.md — Working Rules for This Project

These rules govern how to safely modify the EVA Bot codebase. They assume the
project-wide "Production Coding Rules" already in the global AGENTS.md.

---

## 1. Core Discipline

Follow the ordered workflow on every task:

UNDERSTAND → INSPECT → TRACE → EVIDENCE → ROOT CAUSE → PLAN → TARGETED CHANGE
→ TEST → DIFF REVIEW → VERIFY

Never jump straight into editing. Separate findings into **CONFIRMED**,
**LIKELY**, and **UNKNOWN**. Do not guess when source evidence exists.

## 2. Surgical, Minimal Edits

- Make the **smallest correct change**. Do not rewrite working architecture,
  delete working code, reformat wholesale, or touch unrelated files.
- Preserve public APIs and backward compatibility. Feature flags must degrade
  gracefully (every optional subsystem — Go engine, ContextPool, Camoufox —
  has a pure-Python fallback; keep that property).
- Do **not** add comments unless they document non-obvious intent.

## 3. Planning

- Before editing, record: root cause, target files, target functions, exact
  change, regression risks, validation strategy.
- For non-trivial work, state the plan before writing code.

## 4. Testing

- Coverage uses the existing offline `test_*.py` scripts plus the standard-library
  `unittest` checks in `tests/test_smooth_debug.py`. Do not claim a test passed
  unless it actually ran; optional jsdom checks may be skipped when unavailable.
- Static check: `python -m py_compile entry/main.py entry/paths.py entry/thread_manager.py browser/browser_automation.py core/config_loader.py core/debug.py`.
  Import check: `python -c "import chat"`; diagnostics check:
  `python tests/test_smooth_debug.py`.
- Clearly distinguish **static verification** from **runtime verification**.

## 5. Critical / Fragile Areas (touch with care)

- **`browser/browser_automation.py` (~3600 lines)** — core lifecycle (login,
  chat loop, ban detection). Single-thread-per-worker; do not assume thread
  safety.
- **`entry/thread_manager.py` (~1250 lines)** — orchestration + Qt signals.
- **`entry/main.py` (~1610 lines)** — GUI entry; device-signin gate.
- **`chat/rules.py` (~1320 lines)** — the 6-flow conversation engine plus the
  priority-1 `InputOutputEngine` TXT matcher (`data/input/`/`data/output/`
  folders). All external data (config.json, urls.txt, .ico, sessions) lives in
  `data/`; resolve it via `entry/paths.py` (`project_root()`/`data_dir()`), never
  hardcode paths.
- The legacy `conversation_engine.py` was **removed** — only `chat/` exists now.

## 6. Data & Security (REQUIRED)

- **Never commit or log secrets**: account credentials, proxy credentials,
  cookies, tokens, device IDs, `account_sessions/`.
- Do not hardcode new absolute paths into source. If you must touch DB paths,
  route them through `config.json` — see TASKS.md B1 (current hardcoded paths
  in `chat/chat_db.py:19` and `chat/database/loader.py:26-35` are a known risk).
- Validate external file input (accounts/proxies/templates) and bound resources.

## 7. Networking

- Use bounded retries with backoff; no infinite loops.
- Add proper timeouts to network calls (e.g. `device_signin.py`).
- Prefer deterministic waits on observable state over arbitrary sleeps.

## 8. Resume / Handoff Protocol

- Before a session: read `docs/PROJECT_STATE.md` and `docs/TASKS.md` to pick up
  context.
- Keep `TASKS.md` current: mark an item `[x]` only when actually done and
  verified; otherwise leave it `[ ]` and record the blocker.
- On completion of a task, update `TASKS.md`/`PROJECT_STATE.md` only if it
  reflects real state changes.

## 9. Final Response Format

Report: **Result**, **Root Cause**, **Changes** (files + lines), **Verification**
(only commands actually run), **Remaining Risk**. Never claim "100% working"
without evidence.

## 10. Git

This project lives in the `papipapi` Git repository. Do not initialize a nested
repository or change branches. Only commit when explicitly asked; follow the
repository ignore rules and never commit session state, credentials, or debug
artifacts.

## 11. COMPLETED TASKS (DO NOT TOUCH)

The following tasks have been completed and verified. Do NOT modify these files
unless explicitly asked by the user:

### Phase 1 — Critical Bug Fixes ✅
- [x] `entry/main.py`: GUI loads snap_ids.txt + flirty_questions.txt (were hardcoded `[]`)
- [x] `entry/main.py`: Create mode shows error and returns (was launching with zero accounts)
- [x] `entry/thread_manager.py`: Accounts only marked "failed" on actual errors (was burning every account)
- [x] `entry/thread_manager.py`: Force-cleanup calls `_stop_context_pool()` (was leaking resources)
- [x] `chat/rules.py`: `{snap}` placeholder resolved via `_resolve_snap_reply()`
- [x] `chat/database/loader.py`: DB paths configurable via `EVA_BOT_DB_ROOT` env var

### Phase 2 — High Priority Fixes ✅
- [x] `chat/rules.py`: Style mirroring enabled after 5 messages
- [x] `chat/rules.py`: Multi-line messages — only last line processed through full machine
- [x] `entry/main.py`: Log filtering clears on log clear
- [x] `browser/browser_automation.py`: `_kill_orphan_camoufox()` accepts engine param
- [x] `browser/browser_automation.py`: Proxy URL double-scheme fixed

### Phase 3 — Medium Priority Fixes ✅
- [x] `chat/horny_flirty_db.py`: Word-boundary matching in `match_horny()` and `match_flirty()`
- [x] `entry/thread_manager.py`: Non-blocking thread stagger using `QCoreApplication.processEvents()`
- [x] `entry/main.py`: Stats counting uses `message.startswith("Stranger: ")`
- [x] `core/resource_governor.py`: `psutil.cpu_percent(interval=None)` non-blocking
- [x] `browser/device_signin.py`: Bare `except:` → `except Exception:`

### Phase 4 — Dead Code Cleanup ✅
- [x] `chat/rules.py`: Removed 352 lines of unused pool definitions
- [x] `chat/rules.py`: Restored accidentally removed `FLOWS` dict and `SNAP_GATE_REPLIES`
- [x] `chat/style_analyzer.py`: Removed no-op `replace(" gonna ", " gonna ")`
- [x] `chat/horny_flirty_db.py`: Removed unused `get_horny_snap_hint()` function

### Phase 5 — Smarter Chat Rules ✅
- [x] `chat/rules.py`: Flow-type influence — 70% main pool / 30% flow-specific step4 pool
- [x] `chat/rules.py`: Memory-aware follow-ups using known facts
- [x] `chat/rules.py`: Retry bound reduced from 60→20 in `_session_unused_line()`

### Phase 6 — Test Fixes & Verification ✅
- [x] `test_live.py`: Phase 9 pattern detector assertion fixed
- [x] All 9 modified files pass `py_compile`
- [x] All imports verified
- [x] `test_live.py`: 51/51 passed
- [x] `test_fuzz.py`: 4/4 passed

### Phase 7 — File Cleanup & Debug Output ✅
- [x] Removed 7 dead txt files (01_greeting.txt, 02_age_gender.txt, 03_country.txt, asksc.txt, flirty.txt, normal.txt, sharesc.txt)
- [x] Merged 127 unique lines into active files
- [x] Added line number tracking for debug output
- [x] `tools/live_chat.py`: Debug shows exact file path + line number

### Phase 8 — Country Collection Fix ✅
- [x] `chat/rules.py`: Country collection now goes directly to flirty_questions.txt (was replying from country.txt)

### Phase 9 — Hardcoded Pools to TXT Files ✅
- [x] Created 10 new txt files for previously hardcoded pools
- [x] All pools now load from editable txt files
- [x] Debug output shows exact file path + line number

### Phase 11 — Stranger-SMS detection ("bot user er sms detect korte parche na") ✅
- [x] NEW `browser/chat_reader.py` — multi-selector DOM reader + diagnostics
      (container / item / username / text selector chains, ancestor filtering,
      alignment-class and "text we just sent" speaker fallbacks, and a generic
      `Name: message` line parser for unknown markup)
- [x] `browser/browser_automation.py`: `extract_chat_from_page()` now uses the
      new reader, keeps the ORIGINAL selector set as `_extract_chat_from_page_legacy`
      fallback, caches own username, and logs a loud warning (once) when the page
      cannot be parsed; `EVA_DUMP_CHAT_DOM=1` saves the page HTML for fixing selectors
- [x] `browser/browser_automation.py`: replaced the `len(dom) > last_message_count`
      arithmetic (which went blind whenever the site did not render our own message)
      with `chat_reader.MessageTracker` (fingerprint diff per poll)
- [x] NEW `test_chat_detect.py` — offline tracker, extractor wiring, and browser
      integration checks; DOM-fixture checks use optional jsdom and are skipped
      when it is not installed.
- [x] NEW `tools/chat_detect_debug.py` — shows exactly what the bot can read
      (`--html saved_page.html` or `--url …`)
- [x] Regression suites unchanged: test_flow 124/124, test_live 44/44, test_fuzz 4/4,
      test_matcher round-trip OK, demo_flow/demo_chat PASS

### Phase 10 — Simplified Logic ✅
- [x] `chat/rules.py`: Removed complex state machine from `_decide_reply()`
- [x] Replaced with simple flow: IOEngine scan → horny/flirty/normal detection → asksc → sharesc → END
- [x] `chat/horny_flirty_db.py`: Moved compliment keywords from HORNY to FLIRTY (PATH A vs PATH B)
- [x] `data/input/02_age_gender.txt`: Added female triggers (f20, f 21, etc.)
- [x] `test_live.py`: Updated Phase 5 (removed persona assertions), Phase 8 (love = flirty), Phase 10 (ok/brb = normal)
- [x] All 44/44 test_live passed, 4/4 test_fuzz passed, 21/21 test_matcher passed

### Phase 12 — Selector fix from live capture (session_20261011_012346) ✅
- [x] Evidence: `docs/CAPTURE_2026-10-11.md` — `username_span`,
      `sidebar_truncate_user` and `sidebar_bg_panel_user` all report a **0.0
      hit rate** on the live page, so every row parsed with an empty username
      and speaker attribution collapsed to "anything I did not just send is
      the stranger" (the bot could answer its own message)
- [x] `browser/chat_reader.py`: `_USERNAME_SELECTORS` += the aria-label
      candidates (`button[aria-label^='View @']…`); new `ariaName()` parses
      `View @<name> profile`; new `isGroupBreak()` + sticky username so
      continuation rows (which render no name) inherit the author; new
      `isNonMessageRow()` skips the spacer / banner / system notice / typing
      dots rows (counted in `diag.skipped`). All additive — original selectors
      still match first
- [x] `browser/browser_automation.py`: new `_resolve_my_username(page)` reads
      our own username from `GET /users/me` (cookie-authenticated, one-shot,
      cached, ≤1 retry/minute, string-only) because the sidebar selectors that
      used to provide it are dead
- [x] NEW `tests/fixtures/chat_dom/chat_v6_capture_aria_username.html` —
      faithful reconstruction of the captured markup; `chat_v3_plain_li.html`
      gained a typing-dots + system-notice row
- [x] `test_chat_detect.py`: 5 new checks. With jsdom available the suite is
      **58 passed, 0 failed** (it was 34 — the DOM fixture checks had never
      run in this environment). Run them with
      `EVA_JSDOM_DIR=<dir with node_modules/jsdom> python test_chat_detect.py`

### Phase 13 — Headless mode: Socket.IO with NO browser open ✅
- [x] NEW `headless/` package — `session_file.py` (cookies + release token,
      0600, domain-scoped cookie headers), `capture.py` (the ONE browser run;
      lifts the token out of the site's own `40{"release":…}` CONNECT frame),
      `api.py` (aiohttp REST client, cookie auth only — never an
      `Authorization` header), `client.py` (Socket.IO wrapper: auth payload,
      Engine.IO heartbeat, event routing), `worker.py` (matchUpdate ->
      `ChatRuleBot` -> `POST /users/me/conversations/{id}/messages`)
- [x] NEW `run_headless.py` — `--capture` / `--check` / `--run` / `--probe` /
      `--list` / `--delete`. Nothing in `headless/` imports PyQt6, so the
      browserless path needs no display
- [x] Dead ends avoided on purpose: raw `websockets` (no Engine.IO handshake),
      sending chat text over the socket, Bearer auth — all contradicted by the
      capture
- [x] NEW `tests/test_headless_client.py` — **50 passed, 0 failed**, incl. an
      end-to-end section that starts a real Socket.IO server + real HTTP API
      on 127.0.0.1 and drives the actual client and worker

### Phase 14 — Dashboard "Session Chat": browserless mode from the GUI ✅
- [x] NEW `entry/session_chat.py` — pure helpers (log tagging, session rows,
      `build_capture_command`) + `SessionChatController` (plain asyncio, no Qt)
      + `SessionChatRunner` / `SessionCaptureRunner` QThread wrappers, defined
      only when PyQt6 imports so the module stays testable without Qt
- [x] `entry/main.py` — new 🔌 **Session Chat** nav page: 🌐 browser capture,
      saved-session table (Start / Stop / Delete per row), live log and live
      `Chats | Sent | Recv` counters; several sessions run at once; `closeEvent`
      stops every runner
- [x] `headless/worker.py` — additive `on_stats` callback only (a UI callback
      that raises is disabled, never allowed to break the chat loop). Chat
      logic, `chat/`, `browser/eva_flow.py` and the pools are untouched
- [x] Delivery is unchanged: receive over Socket.IO, reply over HTTP POST,
      cookie auth, no `Authorization` header
- [x] NEW `tests/test_session_chat.py` — **81 passed, 0 failed**; section D
      builds the real `ChitchatBotGUI` offscreen, presses ▶ Start through the
      QThread and asserts a real Socket.IO server received the engine's reply
      as a cookie-authenticated POST, then that ■ Stop shuts it down
- [x] `data/requirements.txt` += `python-socketio[client]`, `aiohttp`,
      `websockets`; `.gitignore` += `headless_sessions/`
- [x] Docs: `docs/HEADLESS_MODE.md` (capture facts, the unconfirmed message
      encoding, what is and is not verified against the live host)

### Runtime diagnostics update ✅
- [x] `core/debug.py`: opt-in `EVA_DEBUG` timing and traceback helpers with
      credential redaction and bounded log volume
- [x] `browser/browser_automation.py`: phase timings, exception tracebacks in
      debug mode, and slower polling only after prolonged inactivity
- [x] `core/config_loader.py` + `data/config.json`: configurable idle poll values
- [x] `tests/test_smooth_debug.py`: deterministic offline checks for redaction,
      exceptions, timing, poll bounds, and config normalization

## 12. ACTIVE TASK TRACKING

Current state: **ALL TASKS COMPLETED**

When a new task is assigned:
1. Read this AGENTS.md first to understand what's done
2. Check `docs/TASKS.md` and `docs/PROJECT_STATE.md` for context
3. Identify which files need to be modified
4. Verify the modification doesn't break completed work
5. Run tests: `python test_live.py && python test_fuzz.py`
6. Update this AGENTS.md with the new completed task

## 13. FILE STRUCTURE REFERENCE

### Data Files (ALL EDITABLE BY USER)
```
data/output/
├── greeting.txt          (64 lines) — GREETING state replies
├── age_gender.txt        (52 lines) — AGE/GENDER capture replies
├── country.txt           (976 lines) — COUNTRY capture replies
├── how_are_you.txt       (203 lines) — HOW ARE U replies
├── horny.txt             (36 lines) — HORNY replies
├── flirty_questions.txt  (1004 lines) — FLIRTY_ASK questions
├── ask_snap.txt          (298 lines) — ASKSC (ask snap)
├── share_snap.txt        (23 lines) — SHARESC (share snap)
├── snapchat.txt          (8 lines) — SNAPCHAT request
├── your_age.txt          (17 lines) — AGE question
├── english_only.txt      (4 lines) — ENGLISH ONLY
├── age_ask.txt           (6 lines) — Age collection ask
├── country_ask.txt       (5 lines) — Country collection ask
├── gender_ask.txt        (4 lines) — Gender collection ask
├── country_dodge.txt     (5 lines) — Country dodge response
├── retry_nudge.txt       (4 lines) — Snap retry nudge
├── answer_ack.txt        (10 lines) — Answer acknowledgement
├── agreement_ack.txt     (8 lines) — Agreement acknowledgement
├── agreement_breaker.txt (6 lines) — Agreement streak breaker
├── info_ack.txt          (8 lines) — Info acknowledgement
├── answer_followup.txt   (8 lines) — Answer follow-up
├── middle_chat/
│   ├── horny_reply.txt   (10 lines) — MIDDLE horny path
│   ├── flirty_reply.txt  (40 lines) — MIDDLE flirty path
│   ├── warm_reply.txt    (20 lines) — MIDDLE warm ack
│   ├── new_topic.txt     (6 lines) — Topic shift
│   └── busy_later.txt    (6 lines) — Busy/leaving
```

### Code Files (DO NOT MODIFY UNLESS ASKED)
```
headless/session_file.py — cookies + Socket.IO release token (0600, gitignored)
headless/capture.py    — the ONE browser run that saves that session
headless/api.py        — REST client (cookie auth only, 3 send encodings)
headless/client.py     — Socket.IO client (auth payload, heartbeat, events)
headless/worker.py     — browserless chat loop, reuses chat/rule_bot.py
run_headless.py        — CLI: --capture --check --run --probe --list --delete
entry/session_chat.py  — dashboard glue: log tags, session rows, QThread runners
chat/rules.py          — Main conversation engine (2300+ lines)
chat/rule_bot.py       — ChatRuleBot wrapper
chat/common_scan.py    — Regex classifier
chat/persona.py        — Persona layer
chat/tg_brain.py       — TgBrain fallback
chat/style_analyzer.py — Style mirroring
chat/horny_flirty_db.py — Horny/flirty detection
chat/database/loader.py — DB loader
entry/main.py          — GUI dashboard
entry/thread_manager.py — Thread orchestration
browser/browser_automation.py — Browser worker
browser/chat_reader.py — Stranger-SMS detection (multi-selector + tracker)
test_chat_detect.py    — Detection tests (offline checks + optional jsdom fixtures)
core/debug.py          — Opt-in, redacting timing/traceback helpers
tests/test_smooth_debug.py — Offline runtime-diagnostics tests
tools/chat_detect_debug.py — "what can the bot read?" page inspector
```

## 14. CRITICAL RULES FOR FUTURE AGENTS

1. **NEVER modify a file unless the user explicitly asks for that specific file**
2. **ALWAYS run `python test_live.py && python test_fuzz.py` after any change**
3. **ALWAYS read AGENTS.md first to understand what's completed**
4. **Make the SMALLEST correct change — no rewriting, no reformatting**
5. **If a task seems complex, ask the user for clarification first**
6. **Document what you changed and why in the final response**
7. **Never claim "100% working" without running tests**
