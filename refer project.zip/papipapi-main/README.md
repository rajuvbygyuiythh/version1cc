# EVA Bot — Full Project (Diagram Flow Engine + Legacy Engine)

Complete EVA chitchat.gg bot: browser automation, PyQt6 GUI dashboard, CLI
runner, account/session management — now running the **updated diagram flow
logic** with **symmetric input/output txt categories**, plus the original
full engine kept as a selectable legacy option.

```
DEFAULT ENGINE (flow):   greeting -> age/gender -> country -> flirty
                         -> positive reply -> share snap -> END CHAT
LEGACY ENGINE:           EVA_ENGINE=legacy  (original 6-flow brain)
```

---

## The one rule (customizable without code)

```
data/input/<category>.txt   = WHAT THE USER SAYS   (trigger keywords)
data/output/<category>.txt  = WHAT THE BOT REPLIES (reply lines)

same file name = same category — edit the txt files, restart, done.
```

Example: user sends `m 21` → matches a line in `input/age_gender.txt` →
bot replies from `output/age_gender.txt` (`f19`).

| # | User says | Category | Next |
|---|-----------|----------|------|
| 1 | first SMS `hi` | `greeting.txt` | wait age/gender |
| 2 | `m21` | `age_gender.txt` | wait country |
| 3 | `from?` | `country.txt` | wait country answer |
| 4 | `usa` | → `flirty_questions.txt` | MIDDLE |
| 5a | `u horny?` / `send nudes` | `horny.txt` | MIDDLE |
| 5b | `ur cute` / `love u` | `middle_chat/flirty_reply.txt` | MIDDLE |
| 5c | `lol` / `ok` / `nice` | `middle_chat/warm_reply.txt` | MIDDLE |
| 5d | `gtg` / `bye` / `brb` | `middle_chat/busy_later.txt` | MIDDLE |
| 5e | `how are u` / `how old are u` | `how_are_you.txt` / `your_age.txt` | MIDDLE |
| 5f | **positive**: `yes` / `yeop` / `ur sc?` / `whats ur snap` | `share_snap.txt` | **END CHAT** |
| 5g | user offers snap: `my snap is…` | `snapchat.txt` | **END CHAT** |
| 5h | anything else | `flirty_questions.txt` | MIDDLE |
| 6 | after 8 bot replies | `closer.txt` | **END CHAT** |

Matching layers (one fails → next works): exact → substring →
slang-normalized → token-subset → smart fallback (regex, countries.txt).

**Bangla A-to-Z guide:** `data/output/info.txt` (কোন SMS পেলে কোন ফাইল
থেকে reply আসবে — সব বাংলায় ব্যাখ্যা করা)।

---

## Headless mode — chat with NO browser open

One browser run saves the session; every run after that talks to chitchat.gg
straight over the Socket.IO websocket, with no browser process at all.

```bash
pip install "python-socketio[client]" aiohttp websockets
python run_headless.py --capture --account me@mail.com   # ONE browser run
python run_headless.py --check   --account me@mail.com   # session still valid?
python run_headless.py --run     --account me@mail.com   # browserless chat
```

* receive — Socket.IO event `chatMessage` on
  `wss://api.chitchat.gg/socket.io/`, authenticated by the CONNECT packet
  `40{"release":"<hash>"}`; the token is lifted from the site's **own**
  websocket frame during capture, so we never guess where it is stored
* send — `POST /users/me/conversations/{id}/messages` (never over the socket)
* auth — cookies only; no `Authorization` header is ever sent
* replies come from the same `data/output/*.txt` pools (`chat/rule_bot.py`)

### From the dashboard (🔌 Session Chat tab)

The same thing, driven from the GUI:

1. **🌐 Start Browser** — type the account email, log in once, close the
   window. The session is saved to `headless_sessions/` automatically.
2. **Saved Sessions** — every saved session is listed with its username and how
   long ago it was captured.
3. **▶ Start** — connects over the websocket with **no browser at all** and
   chats; **■ Stop** finishes the current message and shuts down cleanly.
   Several sessions can run at once, each on its own thread.
4. **Live Log** — `[WS]` / `[MATCH]` / `[RECV]` / `[SEND]` lines plus live
   `Chats | Sent | Recv` counters per session.

The engine is untouched — the dashboard runs the very same `ChatRuleBot` and the
same `data/output/*.txt` pools; only the delivery changed (Playwright →
websocket in / HTTP POST out).

Full details, the capture evidence and the one open question (the exact send
encoding) are in `docs/HEADLESS_MODE.md`.

## Engine switch

```bash
python -m entry.main                # GUI (default = flow engine)
EVA_ENGINE=legacy python -m entry.main   # GUI with the original engine
python entry/cli_runner.py          # terminal runner
```

Both engines share `data/input/` + `data/output/` and the same
`ChatRuleBot` API, so the browser worker, GUI and tools work with either.

## Install & run (Windows)

```bat
install.bat      :: venv + all packages + Playwright Chromium (one run)
run.vbs          :: start the bot app (GUI, NO console window)
"EVA Bot" desktop :: created by install.bat - double-click app icon
run_console.bat  :: debug launcher (console visible)
test.bat         :: automated checks + demo + live REPL
```

Manual (any OS): `python -m venv .venv` → `pip install -r
data/requirements.txt` → `python -m playwright install chromium`.

## Offline verification

The following checks were run in this checkout. The DOM-fixture checks in
`test_chat_detect.py` need `node` + `npm install jsdom` (or `EVA_JSDOM_DIR`
pointing at a folder that has `node_modules/jsdom`); with jsdom present the
suite reports 58 checks instead of 34.

| Command | Result |
|---------|--------|
| `python test_flow.py` | **124 passed, 0 failed** |
| `python test_live.py` | **44/44 passed** |
| `python test_fuzz.py` | **4/4 passed** |
| `python test_matcher.py` | **All categories round-trip OK** |
| `python test_chat_detect.py` | **58 passed, 0 failed** with jsdom (34 without it) |
| `python tests/test_headless_client.py` | **50 passed, 0 failed** (needs the socket.io deps) |
| `python tests/test_session_chat.py` | **81 passed, 0 failed** (incl. the real GUI; 32 without the deps) |
| `python tests/test_smooth_debug.py` | **10 passed, 0 failed** |

The live browser/GUI workflow was not run in this sandbox.

## Project layout

```
headless/   browserless mode: Socket.IO client, REST client, session capture
entry/      GUI dashboard (main.py), Session Chat page (session_chat.py),
            CLI runner, thread orchestration
browser/    Playwright/Camoufox automation, context pool, sessions,
            human behavior, device sign-in
chat/       rule_bot.py (engine switch) + rules.py (legacy engine)
core/       config loader, opt-in debug diagnostics, resource governor, engine bridge, accounts
config/     eva_config.json (intent tuning)
data/       input/ + output/ categories, countries.txt, snap_ids.txt,
            local_db/, config.json (runtime behavior)
docs/       architecture, flow spec, installers (INSTALL_SMOOTH.*)
tools/      live_chat.py REPL, coverage check
eva_flow.py the diagram funnel engine (default)
run_chat.py / demo_flow.py / test_flow.py   flow-engine tools
install.bat / run.vbs / run_console.bat / test.bat   Windows helpers
```

## Behavior rules

- No line repeats within one conversation; never back-to-back
- Reply cap 8 (`EVA_MAX_REPLIES` env) → `closer.txt` → END
- Underage (<18) permanently blocks snap sharing (both engines)
- Snap usernames cycle round-robin via `data/snap_ids.txt`
- `%username%` / `{snap}` / `{country}` placeholders in reply lines
- Multi-line SMS: last line drives the machine

## Stranger-SMS detection (v2.2 — "bot user er sms detect korte parche na")

The browser worker reads the stranger's SMS through `browser/chat_reader.py`.

What was wrong before: extraction depended on ONE hardcoded selector set
(`main ol` → `li.select-text` → `span.font-bold[role=button]` →
`span.emoji-content`). If any class name changed on the site, or if our own
message was not rendered, the bot silently stopped seeing the stranger — no
error, no reply, just "blind" chats.

What it does now:

1. **Selector chain** — several container / row / username / text selector
   candidates are tried in order (the original ones first, so nothing regresses).
2. **Ancestor filtering** — a message row is never counted twice together with
   the text span inside it.
3. **Speaker detection** — own username from the sidebar, a cached hint, row
   alignment classes (`justify-end`, `self-end`, …), and finally "this text is
   something we just sent". Our own bubbles are never answered.
4. **Unknown markup fallback** — a generic `Name: message` line parser still
   finds SMS in a completely different layout.
5. **Fingerprint tracking** (`MessageTracker`) — new messages are found by
   diffing the DOM against the previous poll instead of the old
   `len(dom) > last_count` counter that ran ahead of the DOM whenever the site
   did not render our own message (the real reason replies were "not detected").
6. **Loud diagnostics** — if 0 messages are parsed for several polls the log
   says so, prints which selectors were tried, and with `EVA_DUMP_CHAT_DOM=1`
   saves the page HTML (`logs/chat_dom_dump_*.html`) so the selectors can be
   pointed at the new markup.

Debug a page by hand (no login needed for the saved-page mode):

```bash
# 1) open the chat page, right-click -> Save as -> "Webpage, HTML only"
python tools/chat_detect_debug.py --html path/to/chat_page.html
python tools/chat_detect_debug.py --url https://chitchat.gg/        # live
```

Tests: `python test_chat_detect.py` (34 offline checks; DOM-fixture checks need
`node` + `npm install jsdom`, otherwise they are skipped with a note). Runtime
diagnostics can be checked with `python tests/test_smooth_debug.py`.

## Stranger-SMS detection (v2.3 — verified against a live capture)

A full traffic/DOM capture of the live site (`session_20261011_012346`,
analysed in `docs/CAPTURE_2026-10-11.md`) showed three of the bot's selectors
are dead:

| selector | hit rate on the live page |
|---|---|
| `span.font-bold[role='button']` (author name) | **0.0** |
| `button .truncate.text-sm.font-bold` (our own name) | **0.0** |
| `.bg-panel button span.truncate` (our own name) | **0.0** |

`main ol`, `li.select-text`, `span.emoji-content` and `textarea[name=message]`
still work. With the author name gone, every row parsed with an empty username,
so speaker attribution fell back to "anything I did not just send is the
stranger" — our own bubble is structurally identical to the stranger's, so the
bot could answer itself.

What changed (all additive — the original selectors still match first):

1. **Author from `aria-label`** — the name now only exists as
   `button[aria-label="View @<name> profile"]`; its own text is a 1-char avatar
   glyph, so the label is parsed instead.
2. **Group inheritance** — the site renders the author header only on the first
   message of a group (later rows are marked `pt-(--message-group-gap)`), so a
   continuation row now inherits the previous author.
3. **Non-message rows skipped** — the list spacer, the match banner, the system
   notice pill and the typing dots (`[role=status]`) share the same `<ol>` and
   are no longer read as SMS.
4. **Our own username from `GET /users/me`** — the sidebar selectors are dead,
   and that endpoint is cookie-authenticated, so the page fetches it once and
   caches it. Without it the aria-label names cannot be attributed to either
   side.

The captured markup is checked in as
`tests/fixtures/chat_dom/chat_v6_capture_aria_username.html`; before the fix it
labelled our own `hi cutie` as `Stranger`, after the fix every row is decided by
username. With jsdom installed the suite is **58 passed, 0 failed**:

```bash
npm install jsdom                                   # or set EVA_JSDOM_DIR
python test_chat_detect.py                          # 58 passed, 0 failed
```

## Runtime debug mode

Normal runs keep phase timings and traceback details quiet. To see why a chat
poll or reply is slow, enable the opt-in diagnostics before starting the bot:

```bat
set EVA_DEBUG=1
run_console.bat
```

The log adds `[T] extract: …ms` and `[T] engine: …ms` entries. Errors retain a
short message in normal mode; `EVA_DEBUG=1` adds a bounded traceback. Common
authentication fields are redacted by the diagnostic helper. In windowless GUI
mode, Python output is also appended to `data/logs/gui_console.log`; the rule
engine writes its decision trace to `data/logs/chat_debug.log`.

After 30 seconds with no detected chat activity, polling backs off to
`performance.idle_poll_interval_seconds` (default 1.5 seconds); active polling
still uses `performance.poll_interval_seconds`. Both values are editable in
`data/config.json`.

For a selector/DOM problem, `EVA_DUMP_CHAT_DOM=1` writes a page snapshot under
`logs/`. A snapshot can contain chat messages and page data: review and redact
it before sharing. Turn diagnostics off after collecting the evidence:

```bat
set EVA_DEBUG=
set EVA_DUMP_CHAT_DOM=
```

## Changes vs the original 22.zip snapshot

1. `data/input` + `data/output` renamed to direct symmetric names
   (`01_greeting.txt` → `greeting.txt`, …) + new categories
   (`middle_chat/` inputs, `share_snap.txt` triggers, `closer.txt`)
2. `chat/rule_bot.py`: engine switch (default flow, `EVA_ENGINE=legacy`)
3. `chat/rules.py`: filename refs updated + two fixes
   (punctuation-lossy trigger guard; minors never get IO snap reveals)
4. `eva_flow.py` + tools added (diagram engine, same API)
5. Legacy test scripts pinned to `EVA_ENGINE=legacy`
6. `data/countries.txt` added (editable country keywords)
7. `data/output/info.txt` — Bangla guide (A to Z)

This revision also adds `core/debug.py` runtime diagnostics, timings around the
chat extractor/reply engine, bounded redacted tracebacks, and configurable idle
polling. The tracked source intentionally excludes saved account sessions and
runtime logs.
