"""Headless chat loop: Socket.IO in, HTTP POST out, EVA engine in between.

There is no browser anywhere in this path.  The worker

1. reads our own identity from ``GET /users/me`` (so we can tell our own
   ``chatMessage`` echo from the stranger's);
2. waits for ``matchUpdate`` to learn the conversation id;
3. feeds every incoming ``chatMessage`` from the *other* author to
   :class:`chat.rule_bot.ChatRuleBot` — the same engine the browser bot uses,
   so replies come from the same ``data/output/*.txt`` pools;
4. sends each reply with ``POST /users/me/conversations/{id}/messages``
   (never over the socket), preceded by a typing ping and a human-like delay;
5. when the engine reaches its END stage (snap shared, or the reply cap) it
   disconnects the match and queues the next one.
"""

from __future__ import annotations

import asyncio
import random
import time
from typing import Any, Callable, Dict, List, Optional

from core.config_loader import load_human_behavior, load_replies
from headless.api import ApiError, ChitchatAPI
from headless.client import HeadlessChatClient


def _norm(text: Any) -> str:
    return " ".join(str(text or "").split()).strip()


class HeadlessWorker:
    """One account, one conversation at a time, no browser."""

    def __init__(self,
                 client: HeadlessChatClient,
                 api: ChitchatAPI,
                 log: Optional[Callable[[str], None]] = None,
                 bot: Optional[Any] = None,
                 with_interests: bool = False,
                 auto_next: bool = True,
                 mark_read: bool = True,
                 match_backoff_max: float = 120.0,
                 delay_scale: float = 1.0,
                 on_stats: Optional[Callable[[Dict[str, Any]], None]] = None) -> None:
        self.client = client
        self.api = api
        self.log = log or (lambda _msg: None)
        self.with_interests = with_interests
        self.auto_next = auto_next
        self.mark_read = mark_read
        self.match_backoff_max = match_backoff_max
        # 0.0 disables the human-like pauses (tests / benchmarks).
        self.delay_scale = max(0.0, float(delay_scale))
        # Optional progress reporter for a UI (the dashboard's counters).
        # Called with the same dict :meth:`stats` returns; never required.
        self.on_stats = on_stats

        # Reuse the very same reply engine the browser bot runs.
        if bot is None:
            from chat.rule_bot import ChatRuleBot
            bot = ChatRuleBot()
        self.bot = bot

        self.human = load_human_behavior()
        self.replies_cfg = load_replies()

        self.my_id = ""
        self.username = ""
        self.conversation_id = ""
        self.state: Optional[Dict[str, Any]] = None

        # stats
        self.chats = 0
        self.messages_in = 0
        self.messages_out = 0
        self.snaps_shared = 0
        self.match_403s = 0
        self.errors = 0
        self.started_at = 0.0

        self.sent_texts: List[str] = []
        self._stop = asyncio.Event()
        self._match_failures = 0

    # ------------------------------------------------------------------
    # lifecycle
    # ------------------------------------------------------------------
    def _report(self) -> None:
        """Push the current counters to ``on_stats`` (dashboard counters).

        A UI callback must never be able to break the chat loop, so any
        exception disables it instead of propagating.
        """
        callback = self.on_stats
        if callback is None:
            return
        try:
            callback(self.stats())
        except Exception as exc:  # noqa: BLE001 - UI errors are not bot errors
            self.on_stats = None
            self.log(f"[headless] on_stats disabled: {type(exc).__name__}: {exc}")

    async def start(self) -> None:
        self.started_at = time.time()
        try:
            me = await self.api.me()
        except ApiError as exc:
            if exc.status == 0:
                raise RuntimeError(
                    f"cannot reach {self.api.base_url} ({exc.body[:120]}) — "
                    f"network problem, not an expired session"
                ) from exc
            raise RuntimeError(
                f"GET /users/me failed ({exc.status}) — the saved session is "
                f"probably expired; re-run the browser capture"
            ) from exc
        self.my_id = str(me.get("id") or "")
        self.username = str(me.get("username") or "")
        if not self.my_id:
            raise RuntimeError("GET /users/me returned no id — cannot tell our own messages apart")
        self.log(f"[headless] logged in as {self.username or '?'} (id={self.my_id[:8]}…)")
        self._report()

    def stop(self) -> None:
        self._stop.set()

    async def run(self, idle_poll: float = 1.0) -> Dict[str, Any]:
        """Consume socket events until :meth:`stop` is called."""
        while not self._stop.is_set():
            item = await self.client.get_event(timeout=idle_poll)
            if item is None:
                continue
            try:
                await self._dispatch(item)
            except asyncio.CancelledError:
                raise
            except ApiError as exc:
                self.errors += 1
                self.log(f"[headless] API error: {exc}")
                if exc.status in (401, 403) and "/match" in exc.url:
                    self.match_403s += 1
            except Exception as exc:  # noqa: BLE001 - keep the loop alive
                self.errors += 1
                self.log(f"[headless] {type(exc).__name__}: {exc}")
        return self.stats()

    async def _dispatch(self, item: Dict[str, Any]) -> None:
        event = item.get("event")
        data = item.get("data")
        if event == "matchUpdate":
            await self._on_match_update(data or {})
        elif event == "chatMessage":
            await self._on_chat_message((data or {}).get("message") or {})
        elif event == "messageEdited":
            message = (data or {}).get("message") or {}
            self.log(f"[headless] message edited (flags="
                     f"{message.get('flags')}) — ignored")
        elif event == "__disconnected":
            self.log("[headless] socket dropped — waiting for the client to reconnect")
        elif event == "__connect_error":
            self.log(f"[headless] socket refused: {data}")
        # typing / onlineFriends: nothing to do

    # ------------------------------------------------------------------
    # match lifecycle
    # ------------------------------------------------------------------
    async def _on_match_update(self, data: Dict[str, Any]) -> None:
        match = data.get("match") or {}
        conversation = match.get("conversation") or {}
        conversation_id = str(conversation.get("id") or "")
        closure = match.get("closure") or {}
        inactive = any(u.get("inactive") for u in (match.get("users") or []))

        if not conversation_id:
            if data.get("inQueue"):
                self.log("[headless] in the match queue…")
            return

        if conversation_id != self.conversation_id:
            self._begin_chat(conversation_id)

        if closure.get("closed") or inactive:
            await self._end_chat(reason="peer left" if inactive else "closed by site")

    def _begin_chat(self, conversation_id: str) -> None:
        self.conversation_id = conversation_id
        self.state = self.bot.new_conversation()
        self.chats += 1
        self.log(f"[headless] chat #{self.chats} started (conversation={conversation_id[:12]}…)")
        self._report()

    async def _end_chat(self, reason: str) -> None:
        if not self.conversation_id:
            return
        self.log(f"[headless] chat #{self.chats} ended ({reason}) — "
                 f"{self.messages_in} in / {self.messages_out} out")
        self.conversation_id = ""
        self.state = None
        self._report()
        if not self.auto_next or self._stop.is_set():
            return
        await self._next_match()

    async def _next_match(self) -> None:
        """Queue the next stranger.

        No artificial delay on the happy path; after a refusal the wait grows
        exponentially (2s, 4s, 8s … capped at ``match_backoff_max``) because
        the capture shows ``POST /match`` answering 403 while the account was
        neither banned (``/moderation/ban`` 404) nor warned.
        """
        if self._match_failures:
            delay = min(self.match_backoff_max,
                        2.0 * (2 ** min(self._match_failures - 1, 5)))
            self.log(f"[headless] backing off {delay:.0f}s before the next match")
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=delay)
                return                                   # stopped during the wait
            except asyncio.TimeoutError:
                pass
        try:
            await self.api.disconnect_match()
        except ApiError as exc:
            self.log(f"[headless] disconnect_match: {exc.status} (continuing)")
        try:
            await self.api.start_match(with_interests=self.with_interests)
        except ApiError as exc:
            self._match_failures += 1
            if exc.status == 403:
                self.match_403s += 1
                self.log(f"[headless] POST /match refused with 403 — rate limited? "
                         f"{exc.body[:120]}")
            raise
        self._match_failures = 0
        self.log("[headless] queued for the next stranger")

    async def ensure_match(self) -> None:
        """Start a match if the account is idle (called once after start)."""
        try:
            active = await self.api.active_match()
        except ApiError as exc:
            self.log(f"[headless] GET /match/active: {exc}")
            active = {}
        if active.get("inQueue"):
            self.log("[headless] already in the match queue")
            return
        await self._next_match()

    # ------------------------------------------------------------------
    # messages
    # ------------------------------------------------------------------
    async def _on_chat_message(self, message: Dict[str, Any]) -> None:
        if not message:
            return
        author = message.get("author") or {}
        author_id = str(author.get("id") or "")

        # Our own message comes back over the socket too — never answer it.
        if author_id and self.my_id and author_id == self.my_id:
            return
        if str(message.get("type") or "TEXT").upper() != "TEXT":
            self.log(f"[headless] skipping a {message.get('type')} message")
            return
        if str(message.get("conversationId") or "") not in ("", self.conversation_id):
            return                                   # stale conversation

        content = _norm(message.get("content"))
        if not content:
            return
        if self.state is None:
            if not self.conversation_id:
                self._begin_chat(str(message.get("conversationId") or "unknown"))
            else:
                self.state = self.bot.new_conversation()

        self.messages_in += 1
        who = str(author.get("username") or "stranger")
        self.log(f"  {who}> {content}")
        self._report()

        if self.mark_read:
            try:
                await self.api.mark_read(self.conversation_id)
            except ApiError as exc:
                self.log(f"[headless] mark_read: {exc.status}")

        reply = _norm(self.bot.reply(content, self.state))
        pending = [reply] if reply else []
        pending.extend(_norm(p) for p in self.bot.get_pending_replies(self.state))
        for line in pending:
            if line:
                await self._send(line)

        if str(self.state.get("stage") or "").upper() == "END":
            shared = any("share_snap" in str(p) or "snapchat" in str(p)
                         for p in (self.state.get("pools_used") or ()))
            if shared:
                self.snaps_shared += 1
            await self._end_chat(reason="snap shared" if shared else "reply cap / goodbye")

    # ------------------------------------------------------------------
    # sending
    # ------------------------------------------------------------------
    def _human_delay(self, text: str) -> float:
        """Read-the-message pause + typing time, from data/config.json."""
        read = random.uniform(
            float(self.human.get("read_reply_min_seconds", 1.0)),
            float(self.human.get("read_reply_max_seconds", 3.0)),
        )
        cps = random.uniform(
            float(self.human.get("typing_speed_min_cps", 6.0)),
            float(self.human.get("typing_speed_max_cps", 12.0)),
        )
        typing = (len(text) / cps) if cps > 0 else 1.0
        if random.random() < float(self.human.get("micro_idle_chance", 0.25)):
            typing += random.uniform(
                float(self.human.get("micro_idle_min_seconds", 0.5)),
                float(self.human.get("micro_idle_max_seconds", 2.0)),
            )
        return (read + typing) * self.delay_scale

    async def _send(self, text: str) -> None:
        if not self.conversation_id:
            self.log(f"[headless] no conversation — dropping reply: {text!r}")
            return
        try:
            await self.api.typing(self.conversation_id)
        except ApiError as exc:
            self.log(f"[headless] typing ping: {exc.status}")

        await asyncio.sleep(self._human_delay(text))
        if self._stop.is_set():
            return
        result = await self.api.send_message(self.conversation_id, text)
        self.messages_out += 1
        self.sent_texts.append(text)
        self._report()
        status = result.get("status") if isinstance(result, dict) else None
        self.log(f"  eva> {text}" + (f"   [{status}]" if status else ""))

    # ------------------------------------------------------------------
    async def chat_once(self, incoming: List[str]) -> List[str]:
        """Feed a scripted list of stranger messages (used by the tests)."""
        out: List[str] = []
        for text in incoming:
            before = self.messages_out
            await self._on_chat_message({
                "id": f"m{self.messages_in}",
                "conversationId": self.conversation_id,
                "author": {"id": "peer", "username": "tester"},
                "content": text,
                "type": "TEXT",
            })
            out.extend(self.sent_texts[before:])
        return out

    # ------------------------------------------------------------------
    def stats(self) -> Dict[str, Any]:
        return {
            "username": self.username,
            "chats": self.chats,
            "messages_in": self.messages_in,
            "messages_out": self.messages_out,
            "snaps_shared": self.snaps_shared,
            "match_403s": self.match_403s,
            "errors": self.errors,
            "uptime_s": round(time.time() - self.started_at, 1) if self.started_at else 0.0,
            "socket": self.client.stats(),
        }
