"""REST client for chitchat.gg — cookies only, no Authorization header.

Every endpoint here was observed in capture ``session_20261011_012346``:

========================================  ======  =========================
endpoint                                  status  notes
========================================  ======  =========================
``GET   /users/me``                       200     ``{id, username, …}``
``GET   /users/me/limits``                200
``GET   /moderation/standing``            200     ``{standing, …}``
``GET   /moderation/ban``                 404     404 == not banned
``POST  /match``                          201/403 body ``{"withInterests":b}``
``GET   /match/active``                   200     ``{"inQueue": bool}``
``PATCH /match/disconnect``               200
``GET   /users/me/conversations/{id}/messages``   200
``POST  /users/me/conversations/{id}/messages``   201  **sending a message**
``POST  /users/me/conversations/{id}/typing``     201
``PATCH /users/me/conversations/{id}/read``       200
``POST  /auth/logout``                    201
========================================  ======  =========================

The capture recorded the send request with no ``authorization`` header — only
``content-type``, ``referer`` and the ``sec-ch-ua`` family — so authentication
is purely cookie based and this client never sends a Bearer token.

Message body shape
------------------
The capture recorded the send body as an opaque ``_multipart_raw`` blob — the
tool did not decode the form fields — so the *transport* is form based but the
*field name* is not confirmed.  Three encodings are implemented
(``form`` = ``application/x-www-form-urlencoded``, ``multipart`` =
``multipart/form-data``, ``json``); ``mode="auto"`` walks that order on the
first send and then sticks with whatever the server accepted.  Pin one with
``HEADLESS_MESSAGE_MODE=…`` or find out with ``run_headless.py --probe``.
The form field name defaults to ``content`` (``HEADLESS_MESSAGE_FIELD``).
"""

from __future__ import annotations

import asyncio
import os
import uuid
from typing import Any, Callable, Dict, List, Optional

try:  # aiohttp ships with python-socketio's async client
    import aiohttp
except ImportError as exc:  # pragma: no cover - dependency guard
    raise ImportError(
        "headless.api needs aiohttp — install with: "
        "pip install 'python-socketio[client]' aiohttp websockets"
    ) from exc

from headless.session_file import (
    HeadlessSession,
    cookie_header,
)

DEFAULT_TIMEOUT_SECONDS = 20.0
DEFAULT_MESSAGE_FIELD = os.environ.get("HEADLESS_MESSAGE_FIELD", "content")


class ApiError(RuntimeError):
    """An HTTP call failed.

    ``status`` is the HTTP status, or **0** when the request never completed
    (DNS failure, connection refused, TLS error, timeout) — callers can then
    tell "the site said no" from "we could not reach the site".
    """

    def __init__(self, method: str, url: str, status: int, body: str = ""):
        self.method = method
        self.url = url
        self.status = status
        self.body = (body or "")[:600]
        super().__init__(f"{method} {url} -> {status} {self.body[:160]}")


class ChitchatAPI:
    """Thin async wrapper over the endpoints the site's own client calls."""

    def __init__(self,
                 session: HeadlessSession,
                 base_url: Optional[str] = None,
                 timeout: float = DEFAULT_TIMEOUT_SECONDS,
                 message_field: str = DEFAULT_MESSAGE_FIELD,
                 message_mode: str = "auto",
                 log: Optional[Callable[[str], None]] = None) -> None:
        self.session = session
        self.base_url = (base_url or session.api_base or "").rstrip("/")
        self.timeout = timeout
        self.message_field = message_field
        # "auto" | "form" | "multipart" | "json" — auto resolves on the first send
        self.message_mode = (message_mode if message_mode in ("auto", "form", "multipart", "json")
                             else "auto")
        self._log = log or (lambda _msg: None)
        self._http: Optional[aiohttp.ClientSession] = None

    # -- lifecycle -------------------------------------------------------
    async def __aenter__(self) -> "ChitchatAPI":
        await self.start()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    async def start(self) -> None:
        if self._http is None:
            self._http = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                cookie_jar=aiohttp.CookieJar(unsafe=True),  # allow IP/localhost hosts
            )

    async def close(self) -> None:
        if self._http is not None:
            await self._http.close()
            self._http = None

    def _client(self) -> aiohttp.ClientSession:
        if self._http is None:
            raise RuntimeError("ChitchatAPI.start() was not awaited")
        return self._http

    # -- request plumbing -------------------------------------------------
    def _headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        headers: Dict[str, str] = {
            "accept": "application/json, text/plain, */*",
            "user-agent": self.session.user_agent
                          or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                             "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        }
        cookie = cookie_header(self.session.cookies, self.base_url)
        if cookie:
            headers["cookie"] = cookie
        if self.session.origin:
            headers["origin"] = self.session.origin
            headers["referer"] = self.session.origin + "/"
        # Deliberately NO Authorization header: the capture shows cookie auth.
        if extra:
            headers.update(extra)
        return headers

    def url(self, path: str) -> str:
        if path.startswith("http"):
            return path
        return f"{self.base_url}/{path.lstrip('/')}"

    async def request(self, method: str, path: str, *,
                      expect: Optional[tuple] = None,
                      headers: Optional[Dict[str, str]] = None,
                      **kwargs) -> Any:
        """Perform a request and return decoded JSON (or ``None`` for 204)."""
        await self.start()
        url = self.url(path)
        try:
            async with self._client().request(
                method, url, headers=self._headers(headers), **kwargs
            ) as response:
                text = await response.text()
        except asyncio.TimeoutError as exc:
            raise ApiError(method, url, 0, f"timeout after {self.timeout}s") from exc
        except aiohttp.ClientError as exc:
            # DNS / refused / TLS / reset.  Surfaced as status 0 so callers get
            # one exception type instead of aiohttp's whole hierarchy.
            raise ApiError(method, url, 0, f"{type(exc).__name__}: {exc}") from exc
        if expect is not None and response.status not in expect:
            raise ApiError(method, url, response.status, text)
        if not text:
            return None
        try:
            import json
            return json.loads(text)
        except ValueError:
            return text

    # -- account ----------------------------------------------------------
    async def me(self) -> Dict[str, Any]:
        data = await self.request("GET", "/users/me", expect=(200,))
        return data if isinstance(data, dict) else {}

    async def limits(self) -> Dict[str, Any]:
        data = await self.request("GET", "/users/me/limits", expect=(200,))
        return data if isinstance(data, dict) else {}

    async def moderation_standing(self) -> Dict[str, Any]:
        data = await self.request("GET", "/moderation/standing", expect=(200,))
        return data if isinstance(data, dict) else {}

    async def is_banned(self) -> bool:
        """``GET /moderation/ban`` answers 404 when the account is not banned."""
        try:
            await self.request("GET", "/moderation/ban", expect=(200,))
            return True
        except ApiError as exc:
            if exc.status == 404:
                return False          # the capture: 404 == not banned
            if exc.status == 0:
                raise                 # unreachable host != banned
            return True

    async def logout(self) -> None:
        await self.request("POST", "/auth/logout", expect=(200, 201, 204))

    # -- matching ---------------------------------------------------------
    async def start_match(self, with_interests: bool = False) -> Dict[str, Any]:
        data = await self.request(
            "POST", "/match", expect=(200, 201),
            headers={"content-type": "application/json"},
            json={"withInterests": bool(with_interests)},
        )
        return data if isinstance(data, dict) else {}

    async def active_match(self) -> Dict[str, Any]:
        data = await self.request("GET", "/match/active", expect=(200,))
        return data if isinstance(data, dict) else {}

    async def disconnect_match(self) -> None:
        await self.request("PATCH", "/match/disconnect", expect=(200, 204),
                           headers={"content-type": "application/json"}, json={})

    # -- conversation -----------------------------------------------------
    async def messages(self, conversation_id: str) -> List[Dict[str, Any]]:
        data = await self.request(
            "GET", f"/users/me/conversations/{conversation_id}/messages", expect=(200,))
        return data if isinstance(data, list) else []

    async def typing(self, conversation_id: str) -> None:
        await self.request(
            "POST", f"/users/me/conversations/{conversation_id}/typing",
            expect=(200, 201, 204),
            headers={"content-type": "application/json"}, json={},
        )

    async def mark_read(self, conversation_id: str) -> None:
        await self.request(
            "PATCH", f"/users/me/conversations/{conversation_id}/read",
            expect=(200, 204),
            headers={"content-type": "application/json"}, json={},
        )

    # -- sending ----------------------------------------------------------
    # name -> bound sender; populated below the methods it refers to.
    SENDERS: Dict[str, Any] = {}

    def _form(self, content: str, nonce: str, multipart: bool) -> aiohttp.FormData:
        form = aiohttp.FormData()
        # aiohttp only switches to multipart/form-data when a field carries a
        # content type — without it the same fields go out urlencoded.
        form.add_field(self.message_field, content,
                       **({"content_type": "text/plain"} if multipart else {}))
        form.add_field("type", "TEXT")
        form.add_field("nonce", nonce)
        return form

    async def _send_form(self, conversation_id: str, content: str,
                         nonce: str) -> Dict[str, Any]:
        data = await self.request(
            "POST", f"/users/me/conversations/{conversation_id}/messages",
            expect=(200, 201), data=self._form(content, nonce, multipart=False),
        )
        return data if isinstance(data, dict) else {}

    async def _send_multipart(self, conversation_id: str, content: str,
                              nonce: str) -> Dict[str, Any]:
        data = await self.request(
            "POST", f"/users/me/conversations/{conversation_id}/messages",
            expect=(200, 201), data=self._form(content, nonce, multipart=True),
        )
        return data if isinstance(data, dict) else {}

    async def _send_json(self, conversation_id: str, content: str,
                         nonce: str) -> Dict[str, Any]:
        data = await self.request(
            "POST", f"/users/me/conversations/{conversation_id}/messages",
            expect=(200, 201),
            headers={"content-type": "application/json"},
            json={"content": content, "type": "TEXT", "nonce": nonce},
        )
        return data if isinstance(data, dict) else {}

    async def send_message(self, conversation_id: str, content: str,
                           nonce: Optional[str] = None) -> Dict[str, Any]:
        """Send one chat message and return the server's message object."""
        text = str(content or "").strip()
        if not text:
            raise ValueError("refusing to send an empty message")
        if not conversation_id:
            raise ValueError("no conversation id — is there an active match?")
        token = nonce or uuid.uuid4().hex

        sender = self.SENDERS.get(self.message_mode)
        if sender is not None:
            return await sender(self, conversation_id, text, token)

        # auto: walk the encodings once and remember the winner.
        last: Optional[ApiError] = None
        for mode in ("form", "multipart", "json"):
            try:
                result = await self.SENDERS[mode](self, conversation_id, text, token)
            except ApiError as exc:
                last = exc
                self._log(f"[api] {mode} send rejected ({exc.status}) — trying the next encoding")
                continue
            self.message_mode = mode
            return result
        assert last is not None
        raise last

    async def probe_send_mode(self, conversation_id: str) -> Dict[str, Any]:
        """Try both encodings and report which the server accepts.

        Used by ``run_headless.py --probe``.  Sends nothing on failure paths.
        """
        report: Dict[str, Any] = {}
        for mode, sender in (("form", self._send_form),
                             ("multipart", self._send_multipart),
                             ("json", self._send_json)):
            try:
                await sender(conversation_id, "probe", uuid.uuid4().hex)
                report[mode] = "accepted"
            except ApiError as exc:
                report[mode] = f"{exc.status} {exc.body[:120]}"
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - report, never crash
                report[mode] = f"{type(exc).__name__}: {exc}"
        return report


# Resolved here because the table references methods defined above.
ChitchatAPI.SENDERS = {
    "form": ChitchatAPI._send_form,
    "multipart": ChitchatAPI._send_multipart,
    "json": ChitchatAPI._send_json,
}
