"""The ONE browser run: capture cookies + the Socket.IO ``release`` token.

After this, the bot never opens a browser again — :mod:`headless.client`
connects straight to the websocket with what this module saved.

The ``release`` value is not in any documented place, so instead of guessing
where the site keeps it we **watch the site's own websocket** and read the
auth straight out of its Socket.IO CONNECT frame::

    40{"release":"<hash>"}

Playwright exposes every sent frame, so this works no matter which JS bundle,
localStorage key or API response the value originally came from.

The pure helpers (:func:`parse_connect_frame`, :func:`parse_ws_url`) are unit
tested; the Playwright part needs a display and a real login, so it is only
exercised by ``python run_headless.py --capture``.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from headless.session_file import (
    DEFAULT_API_BASE,
    DEFAULT_SOCKET_PATH,
    HeadlessSession,
    save_session,
)

DEFAULT_START_URL = "https://app.chitchat.gg/start/new"

# Engine.IO v4 packet types we care about.
ENGINEIO_OPEN = "0"        # 0{"sid":…,"upgrades":…,"pingInterval":25000,…}
SOCKETIO_CONNECT = "40"    # 40{"release":"…"}   (or 40/namespace,{"release":…})
SOCKETIO_EVENT = "42"      # 42["chatMessage",{…}]

_NAMESPACE_RE = re.compile(r"^40(/[^\s,]*)?,\s*(\{.*\})\s*$", re.DOTALL)


# ---------------------------------------------------------------------------
# Pure helpers (unit tested — no browser needed)
# ---------------------------------------------------------------------------

def parse_connect_frame(payload: Any) -> Optional[Dict[str, Any]]:
    """Return the CONNECT auth dict from a raw socket frame, else ``None``.

    Handles ``40{"release":"x"}`` and the namespaced ``40/ns,{"release":"x"}``.
    Engine.IO control frames (``0{…}``, ``2``, ``3``) and event frames
    (``42[…]``) return ``None``.
    """
    text = payload if isinstance(payload, str) else ""
    if not text:
        try:
            text = bytes(payload).decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            return None
    text = text.strip()
    if not text.startswith(SOCKETIO_CONNECT):
        return None

    body = text[len(SOCKETIO_CONNECT):].strip()
    if body.startswith("/"):                       # namespaced connect
        match = _NAMESPACE_RE.match(text)
        if not match:
            return None
        body = match.group(2)
    if not body:
        return {}
    try:
        data = json.loads(body)
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def extract_release(payload: Any) -> str:
    """The ``release`` token from a CONNECT frame (``""`` when absent)."""
    data = parse_connect_frame(payload) or {}
    return str(data.get("release") or "")


def parse_ws_url(url: str) -> Tuple[str, str]:
    """Split ``wss://api.host/socket.io/?EIO=4…`` into (api_base, socket_path)."""
    parsed = urlparse(str(url or ""))
    scheme = "https" if parsed.scheme in ("wss", "https") else "http"
    host = parsed.netloc
    if not host:
        return DEFAULT_API_BASE, DEFAULT_SOCKET_PATH
    path = parsed.path or DEFAULT_SOCKET_PATH
    path = path.rstrip("/") or DEFAULT_SOCKET_PATH
    return f"{scheme}://{host}", path


def origin_of(url: str) -> str:
    parsed = urlparse(str(url or ""))
    if not parsed.netloc:
        return ""
    scheme = "https" if parsed.scheme in ("wss", "https") else "http"
    return f"{scheme}://{parsed.netloc}"


def summarize_frames(payloads: List[Any]) -> Dict[str, int]:
    """Count Engine.IO/Socket.IO frame types — handy when debugging a capture."""
    counts: Dict[str, int] = {}
    for payload in payloads:
        text = payload if isinstance(payload, str) else ""
        if not text:
            continue
        head = text[:2]
        key = {"0": "engineio.open", "2": "engineio.ping", "3": "engineio.pong",
               "40": "socketio.connect", "42": "socketio.event",
               "41": "socketio.disconnect", "44": "socketio.connect_error"}.get(
            head if head in ("40", "41", "42", "44") else text[:1], "other")
        counts[key] = counts.get(key, 0) + 1
    return counts


# ---------------------------------------------------------------------------
# The browser run
# ---------------------------------------------------------------------------

async def capture_session(account: str,
                          start_url: str = DEFAULT_START_URL,
                          headed: bool = True,
                          storage_state: Optional[str] = None,
                          wait_seconds: float = 240.0,
                          api_base: str = "",
                          log=print) -> HeadlessSession:
    """Log in once, watch the websocket, and save everything we need.

    Opens a real browser, waits for the site to open its Socket.IO connection,
    lifts the ``release`` token out of the CONNECT frame, then stores the
    cookies + identity.  Returns the saved :class:`HeadlessSession`.
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:  # pragma: no cover - needs the browser extras
        raise RuntimeError(
            "the capture step needs Playwright: "
            "pip install playwright && python -m playwright install chromium"
        ) from exc

    import asyncio

    frames: List[Any] = []
    release_box: Dict[str, str] = {}
    ws_url_box: Dict[str, str] = {}

    def _on_framesent(payload):
        try:
            text = getattr(payload, "text", None)
            if text is None:
                return
            frames.append(text)
            if not release_box.get("release"):
                token = extract_release(text)
                if token:
                    release_box["release"] = token
                    log(f"[capture] release token lifted from the CONNECT frame "
                        f"({len(token)} chars)")
        except Exception as exc:  # noqa: BLE001 - never break the page
            log(f"[capture] frame read failed: {type(exc).__name__}: {exc}")

    def _on_websocket(ws):
        try:
            ws_url_box["url"] = ws.url
            log(f"[capture] websocket opened: {ws.url}")
            ws.on("framesent", _on_framesent)
        except Exception as exc:  # noqa: BLE001
            log(f"[capture] websocket hook failed: {type(exc).__name__}: {exc}")

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=not headed)
        context = await browser.new_context(
            storage_state=storage_state or None,
            user_agent=None,
        )
        page = await context.new_page()
        page.on("websocket", _on_websocket)

        log(f"[capture] opening {start_url}")
        await page.goto(start_url, wait_until="domcontentloaded")
        log("[capture] log in in the browser window; waiting for the chat "
            "socket to open…")

        deadline = asyncio.get_event_loop().time() + wait_seconds
        while asyncio.get_event_loop().time() < deadline:
            if release_box.get("release"):
                break
            await asyncio.sleep(1.0)

        if not release_box.get("release"):
            await browser.close()
            raise RuntimeError(
                "no Socket.IO CONNECT frame seen — did the chat page open? "
                f"frames observed: {summarize_frames(frames)}"
            )

        cookies = await context.cookies()
        user_agent = await page.evaluate("() => navigator.userAgent")

        ws_url = ws_url_box.get("url") or ""
        base, socket_path = parse_ws_url(ws_url) if ws_url else (api_base or DEFAULT_API_BASE,
                                                                DEFAULT_SOCKET_PATH)
        if api_base:
            base = api_base.rstrip("/")

        # The page context shares the login cookies, so this needs no header.
        user: Dict[str, Any] = {}
        try:
            response = await context.request.get(f"{base}/users/me")
            if response.ok:
                user = await response.json()
        except Exception as exc:  # noqa: BLE001
            log(f"[capture] GET /users/me failed: {type(exc).__name__}: {exc}")

        await browser.close()

    session = HeadlessSession(
        account=account,
        release=release_box["release"],
        cookies=[dict(c) for c in cookies],
        api_base=base,
        socket_path=socket_path,
        user={k: user.get(k) for k in ("id", "username", "gender", "verified")
              if isinstance(user, dict) and user.get(k) is not None},
        origin=origin_of(start_url),
        user_agent=str(user_agent or ""),
    )
    path = save_session(session)
    missing = session.missing_auth_cookies()
    log(f"[capture] saved {len(session.cookies)} cookies + release token -> {path}")
    if missing:
        log(f"[capture] WARNING: expected login cookies missing: {missing}")
    log(f"[capture] websocket will be {session.ws_endpoint}")
    return session
