"""headless — run the EVA bot with NO browser open.

One browser run captures the account session (cookies + the Socket.IO
``release`` auth token).  After that the bot talks to chitchat.gg directly:

* **receive** — Socket.IO / Engine.IO v4 websocket, events ``chatMessage``,
  ``matchUpdate``, ``typing``, ``messageEdited``, ``onlineFriends``;
* **send** — HTTP ``POST /users/me/conversations/{id}/messages``;
* **auth** — cookies only (``token`` + ``__Secure-text-session``).  The capture
  shows no ``Authorization`` header on any of these requests.

Modules
-------
``session_file``  save/load the captured session (cookies + release token)
``capture``       the ONE browser run that produces it (Playwright)
``api``           aiohttp client for the REST endpoints
``client``        Socket.IO client wrapper (auth payload, event routing)
``worker``        chat loop: matchUpdate -> ChatRuleBot -> POST reply -> skip

Nothing here imports PyQt6, so the headless path runs on a server with no
display.  The browser capture step is the only part that needs Playwright, and
it is imported lazily.
"""

from __future__ import annotations

__all__ = [
    "HeadlessSession",
    "load_session",
    "save_session",
    "session_path",
    "list_sessions",
    "ChitchatAPI",
    "HeadlessChatClient",
    "HeadlessWorker",
    "DEFAULT_API_BASE",
    "DEFAULT_SOCKET_PATH",
]


def __getattr__(name):
    """Import submodules lazily so ``import headless`` never pulls in aiohttp
    or Playwright unless the caller actually needs them."""
    if name in ("HeadlessSession", "load_session", "save_session",
                "session_path", "list_sessions", "DEFAULT_API_BASE",
                "DEFAULT_SOCKET_PATH"):
        from headless import session_file
        return getattr(session_file, name)
    if name == "ChitchatAPI":
        from headless.api import ChitchatAPI
        return ChitchatAPI
    if name == "HeadlessChatClient":
        from headless.client import HeadlessChatClient
        return HeadlessChatClient
    if name == "HeadlessWorker":
        from headless.worker import HeadlessWorker
        return HeadlessWorker
    raise AttributeError(f"module 'headless' has no attribute {name!r}")
