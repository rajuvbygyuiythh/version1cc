"""Save / load the headless session: cookies + the Socket.IO release token.

Produced by ONE browser run (:mod:`headless.capture`) and reused forever after,
so the bot never has to open a browser again.

The file holds live credentials.  It is written with 0600 permissions under
``headless_sessions/`` at the project root, which ``.gitignore`` excludes — do
not commit or share it.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

SESSIONS_DIR_NAME = "headless_sessions"
SESSION_SCHEMA_VERSION = 1

# Confirmed by capture session_20261011_012346:
#   wss://api.chitchat.gg/socket.io/?EIO=4&transport=websocket
DEFAULT_API_BASE = "https://api.chitchat.gg"
DEFAULT_SOCKET_PATH = "/socket.io"

# Cookies the capture showed carrying the login.  Kept for diagnostics only —
# every cookie that matches the host is sent, not just these two.
KNOWN_AUTH_COOKIES = ("token", "__Secure-text-session")


class SessionError(RuntimeError):
    """Raised when a saved session is missing or unusable."""


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def get_sessions_dir(base_dir: Optional[str] = None) -> Path:
    """Return the headless-session directory below the project root."""
    if base_dir is not None:
        return Path(base_dir)
    root = Path(__file__).resolve().parent.parent
    return root / SESSIONS_DIR_NAME


def session_key(account: str) -> str:
    """Stable, filesystem-safe id that does not expose the account email."""
    normalized = str(account or "").strip().lower()
    if not normalized:
        raise ValueError("An account identifier is required")
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:24]


def session_path(account: str, base_dir: Optional[str] = None) -> Path:
    return get_sessions_dir(base_dir) / f"{session_key(account)}.json"


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class HeadlessSession:
    """Everything needed to talk to chitchat.gg without a browser."""

    account: str
    release: str
    cookies: List[Dict[str, Any]] = dataclasses.field(default_factory=list)
    api_base: str = DEFAULT_API_BASE
    socket_path: str = DEFAULT_SOCKET_PATH
    user: Dict[str, Any] = dataclasses.field(default_factory=dict)
    origin: str = ""
    user_agent: str = ""
    created: str = ""
    schema_version: int = SESSION_SCHEMA_VERSION

    # -- derived ---------------------------------------------------------
    @property
    def ws_url(self) -> str:
        """Base URL handed to the Socket.IO client (it appends the path)."""
        return self.api_base

    @property
    def ws_endpoint(self) -> str:
        """The literal websocket URL, for logs and diagnostics."""
        scheme = "wss" if self.api_base.startswith("https") else "ws"
        host = self.api_base.split("://", 1)[-1].rstrip("/")
        return f"{scheme}://{host}{self.socket_path}/?EIO=4&transport=websocket"

    @property
    def user_id(self) -> str:
        return str(self.user.get("id") or "")

    @property
    def username(self) -> str:
        return str(self.user.get("username") or "")

    def cookie_names(self) -> List[str]:
        return [str(c.get("name") or "") for c in self.cookies if c.get("name")]

    def missing_auth_cookies(self) -> List[str]:
        """Known login cookies that are absent — a hint the capture failed."""
        have = {n for n in self.cookie_names()}
        return [n for n in KNOWN_AUTH_COOKIES if n not in have]

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


# ---------------------------------------------------------------------------
# Cookie helpers
# ---------------------------------------------------------------------------

def _host_of(url: str) -> str:
    host = str(url or "").split("://", 1)[-1]
    return host.split("/", 1)[0].split(":", 1)[0].lower()


def cookie_matches(cookie_domain: Any, host: str) -> bool:
    """RFC-6265 style domain match: ``.chitchat.gg`` covers ``api.chitchat.gg``."""
    domain = str(cookie_domain or "").lstrip(".").lower()
    host = str(host or "").lower()
    if not domain:
        return True                      # host-only cookie: caller decided
    return host == domain or host.endswith("." + domain)


def cookie_header(cookies: Iterable[Dict[str, Any]], url: str) -> str:
    """Build a ``Cookie:`` header value for *url* from a stored cookie list."""
    host = _host_of(url)
    parts = []
    for cookie in cookies or []:
        name = cookie.get("name")
        value = cookie.get("value")
        if not name or value is None:
            continue
        if not cookie_matches(cookie.get("domain"), host):
            continue
        parts.append(f"{name}={value}")
    return "; ".join(parts)


def cookies_for_aiohttp(cookies: Iterable[Dict[str, Any]], url: str) -> Dict[str, str]:
    """Same selection as :func:`cookie_header`, as a plain dict."""
    host = _host_of(url)
    out: Dict[str, str] = {}
    for cookie in cookies or []:
        name = cookie.get("name")
        if not name or cookie.get("value") is None:
            continue
        if not cookie_matches(cookie.get("domain"), host):
            continue
        out[str(name)] = str(cookie.get("value"))
    return out


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def _atomic_write_json(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as fh:
            json.dump(value, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def save_session(session: HeadlessSession, base_dir: Optional[str] = None) -> Path:
    """Write *session* to disk and return its path."""
    if not session.account:
        raise SessionError("A session needs an account identifier")
    if not session.release:
        raise SessionError(
            "No Socket.IO release token — the browser capture did not see the "
            "websocket CONNECT frame. Re-run the capture."
        )
    if not session.cookies:
        raise SessionError("No cookies captured — the account is not logged in")
    if not session.created:
        session.created = datetime.now(timezone.utc).isoformat(timespec="seconds")
    path = session_path(session.account, base_dir)
    _atomic_write_json(path, session.to_dict())
    return path


def load_session(account: Optional[str] = None,
                 path: Optional[str] = None,
                 base_dir: Optional[str] = None) -> HeadlessSession:
    """Load a saved session by *account* (or an explicit *path*)."""
    if path:
        file_path = Path(path)
    else:
        if not account:
            raise SessionError("Pass either an account or an explicit session path")
        file_path = session_path(account, base_dir)
    if not file_path.exists():
        raise SessionError(f"No saved headless session at {file_path}")
    try:
        data = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SessionError(f"Cannot read {file_path}: {exc}") from exc

    known = {f.name for f in dataclasses.fields(HeadlessSession)}
    kwargs = {k: v for k, v in data.items() if k in known}
    session = HeadlessSession(**kwargs)  # type: ignore[arg-type]
    if not session.release:
        raise SessionError(f"{file_path} has no release token")
    if not session.cookies:
        raise SessionError(f"{file_path} has no cookies")
    return session


def list_sessions(base_dir: Optional[str] = None) -> List[Dict[str, Any]]:
    """Summarise the saved sessions (never returns cookie values)."""
    directory = get_sessions_dir(base_dir)
    out: List[Dict[str, Any]] = []
    if not directory.is_dir():
        return out
    for file_path in sorted(directory.glob("*.json")):
        try:
            data = json.loads(file_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        cookies = data.get("cookies") or []
        out.append({
            "file": str(file_path),
            "account": data.get("account"),
            "created": data.get("created"),
            "username": (data.get("user") or {}).get("username"),
            "cookies": len(cookies),
            "has_release": bool(data.get("release")),
            "api_base": data.get("api_base"),
        })
    return out


def delete_session(account: str, base_dir: Optional[str] = None) -> bool:
    path = session_path(account, base_dir)
    if path.exists():
        path.unlink()
        return True
    return False
