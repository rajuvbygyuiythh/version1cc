"""Socket.IO client for chitchat.gg — Engine.IO v4 over a websocket.

Confirmed by capture ``session_20261011_012346``:

* endpoint   ``wss://api.chitchat.gg/socket.io/?EIO=4&transport=websocket``
* protocol   Engine.IO v4 / Socket.IO — **not** a raw websocket.  A plain
  ``websockets.connect()`` gets no handshake and no frames; the client must
  speak Engine.IO (``0{…}`` open, ``2``/``3`` ping/pong) and Socket.IO
  (``40{…}`` connect, ``42[…]`` events) on top of it.  ``python-socketio``
  does exactly that, which is why this module wraps it.
* auth       the CONNECT packet is ``40{"release":"<hash>"}`` — passed as
  ``auth=`` so the library frames it for us.
* heartbeat  25 000 ms, negotiated by the server handshake and answered
  automatically by python-engineio.
* inbound    ``chatMessage`` (60), ``typing`` (32), ``onlineFriends`` (22),
  ``matchUpdate`` (12), ``messageEdited`` (4).
* outbound   the site's client emits ``presenceSync`` (18 times, empty
  payload).  Messages are **not** sent over the socket — they go through
  ``POST /users/me/conversations/{id}/messages`` (see :mod:`headless.api`).
"""

from __future__ import annotations

import asyncio
import os
import time
from typing import Any, Awaitable, Callable, Dict, List, Optional

try:
    import socketio
except ImportError as exc:  # pragma: no cover - dependency guard
    raise ImportError(
        "headless.client needs python-socketio — install with: "
        "pip install 'python-socketio[client]' aiohttp websockets"
    ) from exc

from headless.session_file import HeadlessSession, cookie_header

#: Events worth routing to the worker.  Anything else is counted only.
TRACKED_EVENTS = (
    "chatMessage",     # the stranger (or we) sent a message
    "matchUpdate",     # matched / queue state / conversation closed
    "typing",          # the stranger is typing
    "messageEdited",   # a message was edited (flags=1 in the capture)
    "onlineFriends",   # friend presence — not used by the bot
)


class ConnectError(RuntimeError):
    """The Socket.IO CONNECT was refused (usually a stale release token)."""


class HeadlessChatClient:
    """Connect once, then hand inbound events to the worker."""

    def __init__(self,
                 session: HeadlessSession,
                 log: Optional[Callable[[str], None]] = None,
                 reconnection: bool = True,
                 max_queue: int = 500,
                 presence_interval: float = 0.0) -> None:
        self.session = session
        self._log = log or (lambda _msg: None)
        self._queue: "asyncio.Queue[Dict[str, Any]]" = asyncio.Queue(maxsize=max_queue)
        self._handlers: Dict[str, List[Callable[[Dict[str, Any]], Any]]] = {}
        self._presence_interval = presence_interval
        self._presence_task: Optional[asyncio.Task] = None
        self.last_error: str = ""
        self.connected_at: float = 0.0
        self.event_counts: Dict[str, int] = {}
        self.messages_received = 0
        self._verbose = str(os.environ.get("HEADLESS_WS_DEBUG", "")).strip() not in ("", "0", "false")

        debug = self._verbose
        self.sio = socketio.AsyncClient(
            reconnection=reconnection,
            reconnection_delay=2,
            reconnection_delay_max=30,
            randomization_factor=0.5,
            logger=debug,
            engineio_logger=debug,
        )
        self._register_builtin_handlers()

    # -- wiring -----------------------------------------------------------
    def _register_builtin_handlers(self) -> None:
        @self.sio.event
        async def connect() -> None:                     # noqa: D401 - socketio hook
            self.connected_at = time.time()
            self.last_error = ""
            self._log(f"[ws] connected to {self.session.ws_endpoint}")
            await self._push({"event": "__connected", "data": None})

        @self.sio.event
        async def disconnect() -> None:                  # noqa: D401
            self._log("[ws] disconnected")
            await self._push({"event": "__disconnected", "data": None})

        @self.sio.event
        async def connect_error(data) -> None:           # noqa: D401
            self.last_error = str(data)[:300]
            self._log(f"[ws] CONNECT refused: {self.last_error}")
            await self._push({"event": "__connect_error", "data": self.last_error})

        for name in TRACKED_EVENTS:
            self.sio.on(name, self._make_handler(name))

    def _make_handler(self, name: str):
        async def handler(data=None):
            self.event_counts[name] = self.event_counts.get(name, 0) + 1
            if name == "chatMessage":
                self.messages_received += 1
            await self._push({"event": name, "data": data})
        return handler

    def on(self, event: str, callback: Callable[[Dict[str, Any]], Any]) -> None:
        """Subscribe to a tracked event (in addition to the queue)."""
        self._handlers.setdefault(event, []).append(callback)

    async def _push(self, item: Dict[str, Any]) -> None:
        """Queue an event AND hand it to every subscriber of its name.

        Subscription is how the connection handshake reports success/failure,
        so this must dispatch, not only enqueue.
        """
        try:
            self._queue.put_nowait(item)
        except asyncio.QueueFull:            # never block the socket thread
            self._log("[ws] event queue full — dropping the oldest event")
            try:
                self._queue.get_nowait()
                self._queue.put_nowait(item)
            except asyncio.QueueEmpty:
                pass
        for callback in list(self._handlers.get(item.get("event") or "", ())):
            try:
                result = callback(item)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:  # noqa: BLE001 - a bad handler must not kill the socket
                self._log(f"[ws] handler for {item.get('event')} raised "
                          f"{type(exc).__name__}: {exc}")

    def _requeue(self, item: Dict[str, Any]) -> None:
        """Put an event back without re-dispatching it to subscribers."""
        try:
            self._queue.put_nowait(item)
        except asyncio.QueueFull:
            pass

    # -- connection -------------------------------------------------------
    def _connect_headers(self) -> Dict[str, str]:
        headers: Dict[str, str] = {
            "user-agent": self.session.user_agent
                          or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                             "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        }
        cookie = cookie_header(self.session.cookies, self.session.api_base)
        if cookie:
            headers["cookie"] = cookie
        if self.session.origin:
            headers["origin"] = self.session.origin
        return headers

    @property
    def auth_payload(self) -> Dict[str, str]:
        """The CONNECT auth object — the library frames it as ``40{…}``."""
        return {"release": self.session.release}

    async def connect(self, timeout: float = 30.0) -> None:
        """Open the websocket and wait for the Socket.IO CONNECT to be accepted."""
        if not self.session.release:
            raise ConnectError("session has no release token — re-run the capture")
        accepted = asyncio.Event()
        refused: List[str] = []

        async def _on_connected(_item):
            accepted.set()

        async def _on_error(item):
            refused.append(str(item.get("data")))
            accepted.set()

        self.on("__connected", _on_connected)
        self.on("__connect_error", _on_error)
        try:
            await self.sio.connect(
                self.session.ws_url,
                headers=self._connect_headers(),
                auth=self.auth_payload,
                transports=["websocket"],       # capture: transport=websocket
                socketio_path=self.session.socket_path.strip("/"),
                wait_timeout=timeout,
            )
            await asyncio.wait_for(accepted.wait(), timeout=timeout)
        except (socketio.exceptions.ConnectionError, OSError, asyncio.TimeoutError) as exc:
            raise ConnectError(f"websocket connect failed: {type(exc).__name__}: {exc}") from exc
        finally:
            self._remove_transient(_on_connected, _on_error)

        if refused:
            raise ConnectError(
                f"server refused the CONNECT packet (release token rejected?): {refused[0]}"
            )
        if self._presence_interval > 0:
            self._start_presence()

    def _remove_transient(self, *callbacks) -> None:
        for event, handlers in list(self._handlers.items()):
            for callback in callbacks:
                if callback in handlers:
                    handlers.remove(callback)

    def _start_presence(self) -> None:
        async def _loop():
            while True:
                await asyncio.sleep(self._presence_interval)
                if not self.connected:
                    return
                try:
                    await self.emit("presenceSync")     # capture payload: null
                except Exception as exc:  # noqa: BLE001
                    self._log(f"[ws] presenceSync failed: {type(exc).__name__}: {exc}")
                    return
        self._presence_task = asyncio.ensure_future(_loop())

    async def disconnect(self) -> None:
        if self._presence_task is not None:
            self._presence_task.cancel()
            self._presence_task = None
        try:
            await self.sio.disconnect()
        except Exception:  # noqa: BLE001 - shutdown must not raise
            pass
        # python-engineio creates its own aiohttp session during connect(); a
        # failed handshake leaves it open, which surfaces as an "Unclosed client
        # session" warning at GC time.  Close it unless the caller supplied one.
        eio = getattr(self.sio, "eio", None)
        http = getattr(eio, "http", None)
        if http is not None and not getattr(eio, "external_http", False):
            try:
                await http.close()
            except Exception:  # noqa: BLE001
                pass
            try:
                eio.http = None
            except Exception:  # noqa: BLE001
                pass

    # -- runtime ----------------------------------------------------------
    @property
    def connected(self) -> bool:
        return bool(self.sio.connected)

    @property
    def ping_interval(self) -> float:
        """Negotiated Engine.IO heartbeat (the capture showed 25 000 ms)."""
        try:
            return float(getattr(self.sio.eio, "ping_interval", 0) or 0)
        except Exception:  # noqa: BLE001
            return 0.0

    async def emit(self, event: str, data: Any = None) -> None:
        """Emit an outbound event.  Chat text is NOT sent this way."""
        if data is None:
            await self.sio.emit(event)
        else:
            await self.sio.emit(event, data)

    async def get_event(self, timeout: Optional[float] = None) -> Optional[Dict[str, Any]]:
        """Next inbound event, or ``None`` on timeout."""
        try:
            if timeout is None:
                return await self._queue.get()
            return await asyncio.wait_for(self._queue.get(), timeout=timeout)
        except asyncio.TimeoutError:
            return None

    def drain(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        while not self._queue.empty():
            try:
                out.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        return out

    def stats(self) -> Dict[str, Any]:
        return {
            "connected": self.connected,
            "ping_interval_ms": self.ping_interval * 1000,
            "messages_received": self.messages_received,
            "events": dict(self.event_counts),
            "last_error": self.last_error,
            "queue": self._queue.qsize(),
        }


# Convenience for callers that prefer callbacks over the queue.
async def wait_for_event(client: HeadlessChatClient, event: str,
                         timeout: float = 60.0) -> Optional[Dict[str, Any]]:
    """Block until *event* arrives (other events stay queued)."""
    deadline = time.monotonic() + timeout
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return None
        item = await client.get_event(timeout=remaining)
        if item is None:
            return None
        if item.get("event") == event:
            return item
        client._requeue(item)             # keep everything else in order
        await asyncio.sleep(0)
