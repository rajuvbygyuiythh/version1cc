package main

// Show Mode live chat: after the user logs in manually in the visible Rod
// browser, chatting continues inside that same browser. Incoming messages are
// Socket.IO `chatMessage` frames observed through CDP; replies are sent with
// the page's own authenticated fetch. Protocol evidence and the full design
// live in docs/CHITCHAT_PROTOCOL.md. Normal Rod/ChromeDP login capture is
// untouched: this only runs when BrowserSettings.LiveChat is set (Show Mode).

import (
	"context"
	cryptorand "crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"strings"
	"time"

	"chitchatbot/internal/bot"
	"chitchatbot/internal/browser"
	"chitchatbot/internal/model"
)

const liveAPIBase = "https://api.chitchat.gg"

// ---------------------------------------------------------------------------
// API transport over the backend's page-context fetch (credentials included).
// ---------------------------------------------------------------------------

type liveChatAPI struct {
	backend browser.Backend
}

func (c *liveChatAPI) fetch(ctx context.Context, method, path string, body *string, contentType string) (browser.FetchResponse, error) {
	headers := map[string]string{"accept": "application/json"}
	if contentType != "" {
		headers["content-type"] = contentType
	}
	resp, err := c.backend.Fetch(ctx, browser.FetchRequest{
		Method:  method,
		URL:     liveAPIBase + path,
		Headers: headers,
		Body:    body,
	})
	if err != nil {
		return resp, err
	}
	if resp.Status == 0 {
		return resp, fmt.Errorf("%s %s failed in page: %s", method, path, resp.Text)
	}
	return resp, nil
}

func (c *liveChatAPI) activeConversation(ctx context.Context) (string, error) {
	resp, err := c.fetch(ctx, "GET", "/match/active", nil, "")
	if err != nil {
		return "", err
	}
	var payload struct {
		Match *struct {
			Conversation struct {
				ID string `json:"id"`
			} `json:"conversation"`
		} `json:"match"`
	}
	if err := json.Unmarshal([]byte(resp.Text), &payload); err != nil {
		return "", fmt.Errorf("parse /match/active: %w", err)
	}
	if payload.Match == nil {
		return "", nil
	}
	return payload.Match.Conversation.ID, nil
}

func (c *liveChatAPI) match(ctx context.Context) error {
	body := `{"withInterests":false}`
	resp, err := c.fetch(ctx, "POST", "/match", &body, "application/json")
	if err != nil {
		return err
	}
	if resp.Status == 403 {
		return fmt.Errorf("match refused (403 Flagged); the account may need a manual check in the browser")
	}
	if resp.Status < 200 || resp.Status >= 300 {
		return fmt.Errorf("POST /match status %d: %s", resp.Status, truncateLive(resp.Text, 160))
	}
	return nil
}

func (c *liveChatAPI) disconnect(ctx context.Context) error {
	resp, err := c.fetch(ctx, "PATCH", "/match/disconnect", nil, "")
	if err != nil {
		return err
	}
	if resp.Status < 200 || resp.Status >= 300 {
		return fmt.Errorf("PATCH /match/disconnect status %d", resp.Status)
	}
	return nil
}

func (c *liveChatAPI) sendMessage(ctx context.Context, conversationID, text string) error {
	body, contentType := buildLiveMultipart([][2]string{
		{"content", text},
		{"nonce", newLiveNonce()},
	})
	resp, err := c.fetch(ctx, "POST", "/users/me/conversations/"+conversationID+"/messages", &body, contentType)
	if err != nil {
		return err
	}
	if resp.Status < 200 || resp.Status >= 300 {
		return fmt.Errorf("send message status %d: %s", resp.Status, truncateLive(resp.Text, 160))
	}
	return nil
}

func (c *liveChatAPI) markRead(ctx context.Context, conversationID string) {
	_, _ = c.fetch(ctx, "PATCH", "/users/me/conversations/"+conversationID+"/read", nil, "")
}

func (c *liveChatAPI) sendTyping(ctx context.Context, conversationID string) {
	_, _ = c.fetch(ctx, "POST", "/users/me/conversations/"+conversationID+"/typing", nil, "")
}

func buildLiveMultipart(fields [][2]string) (string, string) {
	boundary := "----chitchat-live-" + newLiveNonce()
	var sb strings.Builder
	for _, f := range fields {
		sb.WriteString("--" + boundary + "\r\n")
		sb.WriteString(fmt.Sprintf("Content-Disposition: form-data; name=%q\r\n\r\n", f[0]))
		sb.WriteString(f[1] + "\r\n")
	}
	sb.WriteString("--" + boundary + "--\r\n")
	return sb.String(), "multipart/form-data; boundary=" + boundary
}

func newLiveNonce() string {
	var b [16]byte
	if _, err := cryptorand.Read(b[:]); err != nil {
		return fmt.Sprintf("nonce-%d", time.Now().UnixNano())
	}
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}

func truncateLive(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "…"
}

// ---------------------------------------------------------------------------
// Reply responders. EVA mode reuses the exported EVAChat engine; sequence
// modes walk the configured lines. Nothing in internal/bot is modified.
// ---------------------------------------------------------------------------

type liveResponder interface {
	Start() []string
	Reply(incoming string) (lines []string, end bool)
}

type detectOnlyResponder struct{}

func (detectOnlyResponder) Start() []string { return nil }
func (detectOnlyResponder) Reply(string) ([]string, bool) {
	return nil, false
}

type sequenceLiveResponder struct {
	lines []string
	next  int
}

func (r *sequenceLiveResponder) Start() []string {
	if len(r.lines) == 0 {
		return nil
	}
	r.next = 1
	return []string{r.lines[0]}
}

func (r *sequenceLiveResponder) Reply(string) ([]string, bool) {
	if r.next < len(r.lines) {
		line := r.lines[r.next]
		r.next++
		return []string{line}, false
	}
	return nil, true
}

type evaLiveResponder struct {
	engine *bot.EVAChatEngine
	state  *model.EVAChatSession
	rng    *rand.Rand
}

func evaLines(result bot.EVAReplyResult) []string {
	lines := []string{}
	if strings.TrimSpace(result.Text) != "" {
		lines = append(lines, result.Text)
	}
	for _, extra := range result.Extra {
		if strings.TrimSpace(extra) != "" {
			lines = append(lines, extra)
		}
	}
	return lines
}

func (r *evaLiveResponder) Start() []string {
	result := r.engine.Start(r.state, r.rng)
	return evaLines(result)
}

func (r *evaLiveResponder) Reply(incoming string) ([]string, bool) {
	result := r.engine.Reply(incoming, r.state, r.rng)
	return evaLines(result), result.Ended
}

func liveSequenceLines(settings model.MessageSettings) []string {
	if settings.EffectiveChatMode() == model.ChatModeFolder && len(settings.LoadedSequences) > 0 {
		var lines []string
		for _, seq := range settings.LoadedSequences {
			lines = append(lines, model.MessageSequenceLines(seq)...)
		}
		return lines
	}
	return settings.SequenceLines()
}

func (a *App) newLiveResponder() (liveResponder, string, error) {
	settings, err := a.uiStore.LoadMessageSettings()
	if err != nil {
		return nil, "", err
	}
	mode := settings.EffectiveChatMode()
	if mode == model.ChatModeEVAChat {
		dataRoot, err := bot.EnsureEVAChatData(a.dataDir)
		if err != nil {
			return nil, "", err
		}
		engine, err := bot.LoadEVAChatEngine(dataRoot)
		if err != nil {
			return nil, "", err
		}
		session := bot.NewEVAChatSession()
		return &evaLiveResponder{
			engine: engine,
			state:  &session,
			rng:    rand.New(rand.NewSource(time.Now().UnixNano())),
		}, "EVAChat Flow", nil
	}
	return &sequenceLiveResponder{lines: liveSequenceLines(settings)}, mode, nil
}

// ---------------------------------------------------------------------------
// Runner: one live conversation at a time inside the open browser.
// ---------------------------------------------------------------------------

type liveRunner struct {
	api          *liveChatAPI
	ownID        string
	prefix       string
	logf         func(level, message string)
	newResponder func() (liveResponder, string, error)
	replyDelay   time.Duration
	pollInterval time.Duration

	conv      string
	responder liveResponder
	seen      map[string]bool
	seenOrder []string
}

func (a *App) runLiveChat(ctx context.Context, backend browser.Backend, login model.LoginInfo, profileName string, index int, total int) {
	prefix := fmt.Sprintf("[%s show-live %d/%d]", profileName, index, total)
	source, ok := backend.(browser.ChatMessageSource)
	if !ok {
		a.log("error", fmt.Sprintf("%s Live chat needs the Rod backend; the %s backend cannot stream chat frames, so the browser will close as usual.", prefix, backend.Name()))
		return
	}
	r := &liveRunner{
		api:          &liveChatAPI{backend: backend},
		ownID:        login.CurrentUserID(),
		prefix:       prefix,
		logf:         a.log,
		replyDelay:   900 * time.Millisecond,
		pollInterval: 8 * time.Second,
		seen:         make(map[string]bool),
		newResponder: a.newLiveResponder,
	}
	a.log("info", fmt.Sprintf("%s Live chat started inside the open browser. Incoming messages will be answered automatically; close the browser window to stop.", prefix))
	r.run(ctx, source)
	a.log("info", fmt.Sprintf("%s Live chat stopped.", prefix))
}

func (r *liveRunner) run(ctx context.Context, source browser.ChatMessageSource) {
	messages := make(chan browser.ChatMessage, 32)
	if err := source.SubscribeChatMessages(ctx, func(m browser.ChatMessage) {
		select {
		case messages <- m:
		default: // never block Rod's event goroutine
		}
	}); err != nil {
		r.logf("error", fmt.Sprintf("%s Could not start live message stream: %v", r.prefix, err))
		return
	}
	if r.rotate(ctx) {
		return
	}
	ticker := time.NewTicker(r.pollInterval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			if r.checkConversation(ctx) {
				return
			}
		case m := <-messages:
			if r.handleMessage(ctx, m) {
				return
			}
		}
	}
}

func (r *liveRunner) pageGone(err error) bool {
	if errors.Is(err, browser.ErrPageUnavailable) {
		r.logf("info", fmt.Sprintf("%s Browser page closed; ending live chat.", r.prefix))
		return true
	}
	return false
}

// rotate finds (or creates) the active conversation and starts it. Returns
// true when the runner must stop (browser gone).
func (r *liveRunner) rotate(ctx context.Context) bool {
	id, err := r.api.activeConversation(ctx)
	if err != nil {
		if r.pageGone(err) {
			return true
		}
		r.logf("error", fmt.Sprintf("%s Could not read active conversation: %v", r.prefix, err))
		return false
	}
	if id == "" {
		if err := r.api.match(ctx); err != nil {
			if r.pageGone(err) {
				return true
			}
			r.logf("error", fmt.Sprintf("%s Match failed: %v", r.prefix, err))
			return false
		}
		if sleepLive(ctx, 800*time.Millisecond) {
			return true
		}
		id, err = r.api.activeConversation(ctx)
		if err != nil {
			if r.pageGone(err) {
				return true
			}
			r.logf("error", fmt.Sprintf("%s Could not read matched conversation: %v", r.prefix, err))
			return false
		}
	}
	if id != "" && id != r.conv {
		return r.startConversation(ctx, id, true)
	}
	return false
}

func (r *liveRunner) startConversation(ctx context.Context, id string, sendStart bool) bool {
	r.conv = id
	responder, mode, err := r.newResponder()
	if err != nil {
		r.logf("error", fmt.Sprintf("%s Reply engine unavailable (%v); incoming will be detected but not answered.", r.prefix, err))
		responder = detectOnlyResponder{}
		mode = "detect-only"
	}
	r.responder = responder
	r.logf("info", fmt.Sprintf("%s Conversation %s started (reply mode: %s).", r.prefix, id, mode))
	if sendStart {
		return r.sendLines(ctx, responder.Start())
	}
	return false
}

func (r *liveRunner) checkConversation(ctx context.Context) bool {
	id, err := r.api.activeConversation(ctx)
	if err != nil {
		if r.pageGone(err) {
			return true
		}
		r.logf("error", fmt.Sprintf("%s Active conversation check failed: %v", r.prefix, err))
		return false
	}
	if id == "" && r.conv != "" {
		r.logf("info", fmt.Sprintf("%s Partner left; looking for a new match.", r.prefix))
		r.conv = ""
		r.responder = nil
		return r.rotate(ctx)
	}
	if id != "" && id != r.conv {
		r.logf("info", fmt.Sprintf("%s New conversation detected.", r.prefix))
		return r.startConversation(ctx, id, true)
	}
	return false
}

func (r *liveRunner) handleMessage(ctx context.Context, m browser.ChatMessage) bool {
	if m.ID != "" {
		if r.seen[m.ID] {
			return false
		}
		r.remember(m.ID)
	}
	if m.Author == "" || m.Author == r.ownID || strings.TrimSpace(m.Content) == "" {
		return false
	}
	if m.ConversationID != "" && m.ConversationID != r.conv {
		// Partner-initiated or rotated conversation: adopt it without a
		// proactive greeting, then answer this message.
		r.conv = m.ConversationID
		responder, _, err := r.newResponder()
		if err != nil {
			responder = detectOnlyResponder{}
		}
		r.responder = responder
		r.logf("info", fmt.Sprintf("%s Adopted conversation %s from an incoming message.", r.prefix, r.conv))
	}
	if r.responder == nil {
		responder, _, err := r.newResponder()
		if err != nil {
			responder = detectOnlyResponder{}
		}
		r.responder = responder
	}

	r.logf("info", fmt.Sprintf("%s Incoming: %q", r.prefix, truncateLive(m.Content, 120)))
	r.api.markRead(ctx, r.conv)
	r.api.sendTyping(ctx, r.conv)
	if sleepLive(ctx, r.replyDelay) {
		return true
	}
	lines, end := r.responder.Reply(m.Content)
	if r.sendLines(ctx, lines) {
		return true
	}
	if end {
		r.logf("info", fmt.Sprintf("%s Conversation flow ended; skipping to a new partner.", r.prefix))
		if err := r.api.disconnect(ctx); err != nil {
			if r.pageGone(err) {
				return true
			}
			r.logf("error", fmt.Sprintf("%s Skip (disconnect) failed: %v", r.prefix, err))
			return false
		}
		r.conv = ""
		r.responder = nil
		if sleepLive(ctx, time.Second) {
			return true
		}
		return r.rotate(ctx)
	}
	return false
}

func (r *liveRunner) sendLines(ctx context.Context, lines []string) bool {
	for i, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if i > 0 && sleepLive(ctx, 400*time.Millisecond) {
			return true
		}
		if err := r.api.sendMessage(ctx, r.conv, line); err != nil {
			if r.pageGone(err) {
				return true
			}
			r.logf("error", fmt.Sprintf("%s Failed to send reply: %v", r.prefix, err))
			return false
		}
		r.logf("info", fmt.Sprintf("%s Outgoing: %q", r.prefix, truncateLive(line, 120)))
	}
	return false
}

func (r *liveRunner) remember(id string) {
	r.seen[id] = true
	r.seenOrder = append(r.seenOrder, id)
	if len(r.seenOrder) > 200 {
		delete(r.seen, r.seenOrder[0])
		r.seenOrder = r.seenOrder[1:]
	}
}

func sleepLive(ctx context.Context, d time.Duration) bool {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return true
	case <-t.C:
		return false
	}
}
