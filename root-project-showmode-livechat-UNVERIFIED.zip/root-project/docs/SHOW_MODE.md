# Show Mode (third Browser row) — manual login, then live chat in the browser

Available options: 01 Rod, 02 ChromeDP, 03 Show Mode. Each has Run.

## Behaviour

Show Mode is a visible Rod preset with `live_chat` enabled:

1. Run opens a **visible** Rod browser at `app.chitchat.gg` (Headless is
   ignored for this row). Login itself is unchanged: cookies/storage capture
   runs as before, and the login JSON is saved exactly like the other rows.
2. **You** enter email/password and solve any captcha manually.
3. Once login is detected and saved, the browser **does not close**. Live
   chat starts inside that same browser:
   - Incoming partner messages are detected from the page's Socket.IO
     `chatMessage` frames (CDP `Network.webSocketFrameReceived`).
   - Replies come from the currently selected dashboard message mode:
     EVAChat Flow uses the exported EVA engine (Start/Reply per
     conversation); Single/Folder modes walk the configured sequence lines,
     greeting first. The EVA AI compose layer is not applied in live mode.
   - Replies are sent with the page's own authenticated `fetch`
     (`POST /users/me/conversations/:id/messages`, multipart
     `content` + `nonce`) — the exact method the site itself uses.
   - When a conversation flow ends (EVA `Ended`, or the sequence runs out),
     the partner is skipped: `PATCH /match/disconnect` → `POST /match` →
     new conversation. Partner leaving is detected by polling
     `GET /match/active` every ~8s.
   - Own messages and duplicate frames never trigger replies.
4. **Stop:** close the browser window (live chat ends within a few seconds)
   or close the app. The usual temporary-profile cleanup then runs.

Protocol evidence for every method above: `docs/CHITCHAT_PROTOCOL.md`
(captured from the real site, 2026-10-14). If Rod is unavailable the backend
cannot stream chat frames, so live chat logs an error and the browser closes
as before. If the reply engine fails to load, messages are still detected
and logged but not answered (detect-only fallback).

## Settings and persistence

The frontend sends `show_mode`; `validateBrowserRun` normalizes it to
`backend=rod`, `headless=false`, `live_chat=true` **before** saving defaults
or dispatching, so saved sessions keep the real backend name. Rod/ChromeDP
rows never set `live_chat`. The Headless checkbox is not changed by the
click; Rod/ChromeDP continue to use it normally.

## Tests (browser-free)

- `live_chat_test.go`: fake backend drives the whole runner — proactive
  greeting, partner reply, own-message ignore, duplicate suppression, and
  skip-to-new-partner on sequence end. EVA responder start is covered too.
- `internal/browser/livechat_test.go`: Socket.IO frame parser (real captured
  shapes), also runnable standalone since the parser is stdlib-only.
- Full Go compilation and a real Windows browser run remain subject to the
  verification report; no live browser was run while writing this.
