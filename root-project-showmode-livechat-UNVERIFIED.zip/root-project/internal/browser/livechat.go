package browser

import (
	"context"

	"github.com/go-rod/rod/lib/proto"
)

// ChatMessageSource is implemented by backends that can stream realtime chat
// messages out of the live page (Show Mode live chat). It is an optional
// interface: the login-capture Backend contract is unchanged, and ChromeDP
// simply does not implement it.
type ChatMessageSource interface {
	SubscribeChatMessages(ctx context.Context, handler func(ChatMessage)) error
}

// SubscribeChatMessages streams incoming `chatMessage` Socket.IO frames from
// the page's WebSocket connection via CDP Network events. The handler is
// called from Rod's event goroutine; delivery stops when ctx is cancelled or
// the page goes away. Protocol evidence: docs/CHITCHAT_PROTOCOL.md.
func (b *RodBackend) SubscribeChatMessages(ctx context.Context, handler func(ChatMessage)) error {
	page, err := b.currentPage(ctx)
	if err != nil {
		return err
	}
	if err := (proto.NetworkEnable{}).Call(page); err != nil {
		return err
	}
	wait := page.Context(ctx).EachEvent(func(e *proto.NetworkWebSocketFrameReceived) {
		if e == nil || e.Response == nil {
			return
		}
		if msg, ok := ParseChatMessageFrame(e.Response.PayloadData); ok {
			handler(msg)
		}
	})
	go wait()
	return nil
}
