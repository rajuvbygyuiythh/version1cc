package browser

import "testing"

func TestParseChatMessageFrame(t *testing.T) {
	payload := `42["chatMessage",{"message":{"id":"m1","conversationId":"c1","author":"u2","content":"hello there","type":"TEXT","createdAt":"2026-10-14T12:54:05Z"}}]`
	msg, ok := ParseChatMessageFrame(payload)
	if !ok {
		t.Fatal("expected chatMessage frame to parse")
	}
	if msg.ID != "m1" || msg.ConversationID != "c1" || msg.Author != "u2" || msg.Content != "hello there" || msg.Type != "TEXT" {
		t.Fatalf("unexpected message: %#v", msg)
	}
}

func TestParseChatMessageFrameRejectsOtherPackets(t *testing.T) {
	for _, payload := range []string{
		"",
		"2",
		"3",
		`40{"release":"abc"}`,
		`42["typing",{"userId":"u2","conversationId":"c1"}]`,
		`42["presenceSync"]`,
		`42["chatMessage",{"message":{"id":"","conversationId":"c1","content":"x"}}]`,
		`42["chatMessage",{"message":{"id":"m1","conversationId":"c1","content":"  "}}]`,
		"not json",
	} {
		if msg, ok := ParseChatMessageFrame(payload); ok {
			t.Fatalf("accepted non-chat payload %q: %#v", payload, msg)
		}
	}
}

func TestParseChatMessageFrameBareShapes(t *testing.T) {
	if _, ok := ParseChatMessageFrame(`{"message":{"id":"m","conversationId":"c","author":"a","content":"hi"}}`); !ok {
		t.Fatal("bare object should parse")
	}
	if _, ok := ParseChatMessageFrame(`["chatMessage",{"message":{"id":"m","conversationId":"c","author":"a","content":"hi"}}]`); !ok {
		t.Fatal("bare array should parse")
	}
}
