package browser

import (
	"encoding/json"
	"strings"
)

// ChatMessage is one realtime chat message observed on the page's Socket.IO
// connection. The schema mirrors docs/CHITCHAT_PROTOCOL.md (capture-proven).
type ChatMessage struct {
	ID             string `json:"id"`
	ConversationID string `json:"conversationId"`
	Author         string `json:"author"`
	Content        string `json:"content"`
	Type           string `json:"type"`
	CreatedAt      string `json:"createdAt"`
}

// ParseChatMessageFrame extracts a chatMessage event from a raw Socket.IO
// WebSocket frame payload. Accepted shapes:
//   - engine.io event packet: 42["chatMessage", {"message": {...}}]
//   - a bare JSON array:      ["chatMessage", {"message": {...}}]
//   - a bare JSON object:     {"message": {...}}
//
// Anything else (pings, presence, typing, connect packets) returns false.
func ParseChatMessageFrame(payload string) (ChatMessage, bool) {
	data := strings.TrimSpace(payload)
	if data == "" {
		return ChatMessage{}, false
	}

	// Strip the engine.io/Socket.IO packet-type digits (e.g. "42").
	if data[0] >= '0' && data[0] <= '9' {
		i := 0
		for i < len(data) && data[i] >= '0' && data[i] <= '9' {
			i++
		}
		data = strings.TrimSpace(data[i:])
		if data == "" {
			return ChatMessage{}, false
		}
	}

	if strings.HasPrefix(data, "[") {
		var arr []json.RawMessage
		if err := json.Unmarshal([]byte(data), &arr); err != nil || len(arr) < 2 {
			return ChatMessage{}, false
		}
		var event string
		if err := json.Unmarshal(arr[0], &event); err != nil || event != "chatMessage" {
			return ChatMessage{}, false
		}
		data = string(arr[1])
	}

	var envelope struct {
		Message ChatMessage `json:"message"`
	}
	if err := json.Unmarshal([]byte(data), &envelope); err != nil {
		return ChatMessage{}, false
	}
	msg := envelope.Message
	if msg.ID == "" || msg.ConversationID == "" || strings.TrimSpace(msg.Content) == "" {
		return ChatMessage{}, false
	}
	return msg, true
}
